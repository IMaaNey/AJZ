"use client";

import { useEffect, useState, useCallback } from "react";
import { Sidebar } from "@/components/Sidebar";
import { Header } from "@/components/Header";
import { Timer } from "@/components/Timer";
import {
  Clock,
  Coffee,
  CheckCircle2,
  AlertCircle,
  Calendar,
  BarChart3,
  TrendingUp,
  Briefcase,
  Play,
  Square,
  Sparkles,
  Info,
} from "lucide-react";
import { useRouter } from "next/navigation";

export default function EmployeeDashboard() {
  const router = useRouter();
  const [user, setUser] = useState<any>(null);
  const [todayData, setTodayData] = useState<any>(null);
  const [monthlySummary, setMonthlySummary] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");
  const [successMsg, setSuccessMsg] = useState("");
  const [mobileNavOpen, setMobileNavOpen] = useState(false);

  const fetchDashboardData = useCallback(async () => {
    try {
      // 1. Fetch User Info
      const userRes = await fetch("/api/auth/me");
      if (!userRes.ok) {
        router.push("/login");
        return;
      }
      const userData = await userRes.json();
      setUser(userData.user);

      // 2. Fetch Today Attendance State
      const todayRes = await fetch("/api/attendance/today");
      if (todayRes.ok) {
        const tData = await todayRes.json();
        setTodayData(tData);
      }

      // 3. Fetch Monthly Summary
      const monthlyRes = await fetch("/api/attendance/monthly-summary");
      if (monthlyRes.ok) {
        const mData = await monthlyRes.json();
        setMonthlySummary(mData);
      }
    } catch (err) {
      console.error("Dashboard fetch error:", err);
    } finally {
      setLoading(false);
    }
  }, [router]);

  useEffect(() => {
    fetchDashboardData();
  }, [fetchDashboardData]);

  const handleLogout = async () => {
    await fetch("/api/auth/logout", { method: "POST" });
    router.push("/login");
  };

  const handleClockIn = async () => {
    setErrorMsg("");
    setSuccessMsg("");
    setActionLoading(true);
    try {
      const res = await fetch("/api/attendance/clock-in", { method: "POST" });
      const data = await res.json();
      if (!res.ok) {
        setErrorMsg(data.error || "Clock In failed");
      } else {
        setSuccessMsg(`Clocked In successfully! ${data.arrivalLabel || ""}`);
        await fetchDashboardData();
      }
    } catch {
      setErrorMsg("Network error trying to clock in");
    } finally {
      setActionLoading(false);
    }
  };

  const handleClockOut = async () => {
    if (!confirm("Are you sure you want to Clock Out for today?")) return;
    setErrorMsg("");
    setSuccessMsg("");
    setActionLoading(true);
    try {
      const res = await fetch("/api/attendance/clock-out", { method: "POST" });
      const data = await res.json();
      if (!res.ok) {
        setErrorMsg(data.error || "Clock Out failed");
      } else {
        setSuccessMsg("Clocked Out successfully!");
        await fetchDashboardData();
      }
    } catch {
      setErrorMsg("Network error trying to clock out");
    } finally {
      setActionLoading(false);
    }
  };

  const handleStartBreak = async () => {
    setErrorMsg("");
    setSuccessMsg("");
    setActionLoading(true);
    try {
      const res = await fetch("/api/attendance/break-start", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ breakType: "LUNCH" }),
      });
      const data = await res.json();
      if (!res.ok) {
        setErrorMsg(data.error || "Start Break failed");
      } else {
        setSuccessMsg("Break started.");
        await fetchDashboardData();
      }
    } catch {
      setErrorMsg("Network error starting break");
    } finally {
      setActionLoading(false);
    }
  };

  const handleEndBreak = async () => {
    setErrorMsg("");
    setSuccessMsg("");
    setActionLoading(true);
    try {
      const res = await fetch("/api/attendance/break-end", { method: "POST" });
      const data = await res.json();
      if (!res.ok) {
        setErrorMsg(data.error || "End Break failed");
      } else {
        setSuccessMsg("Break ended. Back to work!");
        await fetchDashboardData();
      }
    } catch {
      setErrorMsg("Network error ending break");
    } finally {
      setActionLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center text-white font-medium">
        <div className="flex items-center gap-3">
          <div className="w-6 h-6 border-2 border-amber-500 border-t-transparent rounded-full animate-spin"></div>
          <span>Loading AJZ Consultants Portal...</span>
        </div>
      </div>
    );
  }

  const attendance = todayData?.attendance;
  const isClockedIn = !!attendance;
  const isWorking = attendance?.attendanceStatus === "WORKING";
  const isCompleted = attendance?.attendanceStatus === "COMPLETED";
  const activeBreak = todayData?.activeBreak;

  const clockInFormatted = attendance?.clockIn
    ? new Date(attendance.clockIn).toLocaleTimeString("en-US", {
        timeZone: "Asia/Karachi",
        hour: "2-digit",
        minute: "2-digit",
        hour12: true,
      })
    : "—";

  const clockOutFormatted = attendance?.clockOut
    ? new Date(attendance.clockOut).toLocaleTimeString("en-US", {
        timeZone: "Asia/Karachi",
        hour: "2-digit",
        minute: "2-digit",
        hour12: true,
      })
    : "—";

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex text-slate-800 dark:text-slate-100">
      <Sidebar
        role={user?.role || "EMPLOYEE"}
        userName={user?.fullName || "Employee"}
        userEmail={user?.email || ""}
        isOpenMobile={mobileNavOpen}
        onCloseMobile={() => setMobileNavOpen(false)}
        onLogout={handleLogout}
      />

      <div className="flex-1 lg:pl-64 flex flex-col min-w-0">
        <Header
          userName={user?.fullName || "Employee"}
          role={user?.role || "EMPLOYEE"}
          department={user?.department || "General"}
          onOpenMobileNav={() => setMobileNavOpen(true)}
        />

        <main className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto w-full space-y-8">
          {/* Greeting Banner */}
          <div className="bg-gradient-to-r from-slate-900 via-amber-950 to-slate-900 rounded-2xl p-6 sm:p-8 text-white shadow-xl relative overflow-hidden">
            <div className="relative z-10">
              <span className="px-3 py-1 rounded-full text-xs font-semibold bg-amber-500/20 text-amber-300 border border-amber-500/30">
                AJZ Consultants Employee Portal
              </span>
              <h1 className="text-2xl sm:text-3xl font-black mt-3 tracking-tight">
                Good Day, {user?.fullName || "Employee"} 👋
              </h1>
              <p className="text-sm text-slate-300 mt-1 max-w-xl">
                {user?.designation} • {user?.department} Department
              </p>
            </div>
            <div className="absolute -right-10 -bottom-10 w-60 h-60 bg-amber-600/10 rounded-full blur-2xl pointer-events-none"></div>
          </div>

          {/* Messages */}
          {errorMsg && (
            <div className="p-4 bg-rose-500/10 border border-rose-500/30 rounded-xl text-rose-600 dark:text-rose-400 text-sm font-medium flex items-center justify-between">
              <div className="flex items-center gap-2">
                <AlertCircle className="w-5 h-5 shrink-0" />
                <span>{errorMsg}</span>
              </div>
              <button onClick={() => setErrorMsg("")} className="text-xs text-slate-400 hover:text-white">Dismiss</button>
            </div>
          )}

          {successMsg && (
            <div className="p-4 bg-emerald-500/10 border border-emerald-500/30 rounded-xl text-emerald-600 dark:text-emerald-400 text-sm font-medium flex items-center justify-between">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5 shrink-0" />
                <span>{successMsg}</span>
              </div>
              <button onClick={() => setSuccessMsg("")} className="text-xs text-slate-400 hover:text-white">Dismiss</button>
            </div>
          )}

          {/* Grid Layout: Schedule & Main Clock In Card */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* TODAY'S SCHEDULE CARD */}
            <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-sm font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider flex items-center gap-2">
                    <Calendar className="w-4 h-4 text-amber-500" />
                    <span>Today&apos;s Schedule</span>
                  </h3>
                  <span className="text-xs font-semibold px-2.5 py-1 rounded-md bg-amber-50 dark:bg-amber-950/50 text-amber-600 dark:text-amber-400 border border-amber-200 dark:border-amber-800">
                    Asia/Karachi
                  </span>
                </div>

                <div className="space-y-4">
                  <div className="flex items-center justify-between p-3.5 bg-slate-50 dark:bg-slate-950 rounded-xl border border-slate-100 dark:border-slate-800">
                    <span className="text-xs font-medium text-slate-500">Scheduled Start</span>
                    <span className="text-sm font-black text-slate-800 dark:text-white">
                      {todayData?.schedule?.scheduledStartFormatted || "09:00 AM"}
                    </span>
                  </div>

                  <div className="flex items-center justify-between p-3.5 bg-slate-50 dark:bg-slate-950 rounded-xl border border-slate-100 dark:border-slate-800">
                    <span className="text-xs font-medium text-slate-500">Scheduled End</span>
                    <span className="text-sm font-black text-slate-800 dark:text-white">
                      {todayData?.schedule?.scheduledEndFormatted || "06:00 PM"}
                    </span>
                  </div>

                  <div className="flex items-center justify-between p-3.5 bg-slate-50 dark:bg-slate-950 rounded-xl border border-slate-100 dark:border-slate-800">
                    <span className="text-xs font-medium text-slate-500">Grace Period</span>
                    <span className="text-sm font-bold text-amber-600 dark:text-amber-400">
                      {todayData?.schedule?.gracePeriodMinutes || 15} minutes
                    </span>
                  </div>

                  <div className="flex items-center justify-between p-3.5 bg-slate-50 dark:bg-slate-950 rounded-xl border border-slate-100 dark:border-slate-800">
                    <span className="text-xs font-medium text-slate-500">Lunch Break</span>
                    <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                      {todayData?.schedule?.lunchBreakStart} - {todayData?.schedule?.lunchBreakEnd}
                    </span>
                  </div>
                </div>
              </div>

              {todayData?.isHoliday && (
                <div className="mt-4 p-3 bg-slate-100 dark:bg-slate-800 rounded-xl text-xs text-slate-600 dark:text-slate-300">
                  ⚪ <strong>Holiday Today:</strong> {todayData.isHoliday.name}
                </div>
              )}

              {todayData?.isLeave && (
                <div className="mt-4 p-3 bg-purple-500/10 rounded-xl text-xs text-purple-400">
                  🟣 <strong>Approved Leave Today:</strong> {todayData.isLeave.reason}
                </div>
              )}
            </div>

            {/* MAIN CLOCK IN / WORKING / CLOCK OUT CARD */}
            <div className="lg:col-span-2 bg-white dark:bg-slate-900 rounded-2xl p-6 sm:p-8 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between relative overflow-hidden">
              {/* STATE 1: NOT CLOCKED IN */}
              {!isClockedIn && (
                <div className="text-center py-6 my-auto space-y-6">
                  <div className="w-16 h-16 rounded-full bg-amber-50 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400 flex items-center justify-center mx-auto shadow-inner">
                    <Clock className="w-8 h-8" />
                  </div>
                  <div>
                    <h2 className="text-2xl font-black text-slate-900 dark:text-white tracking-tight">
                      Ready to start your workday?
                    </h2>
                    <p className="text-sm text-slate-500 dark:text-slate-400 mt-1 max-w-md mx-auto">
                      Click Clock In to start your official time tracking for AJZ Consultants. Server timestamp will be recorded.
                    </p>
                  </div>

                  <button
                    onClick={handleClockIn}
                    disabled={actionLoading}
                    className="w-full sm:w-auto px-10 py-5 bg-amber-600 hover:bg-amber-500 text-white font-extrabold text-lg rounded-2xl shadow-xl shadow-amber-600/30 transition-all transform active:scale-98 cursor-pointer disabled:opacity-50"
                  >
                    {actionLoading ? "Processing Clock In..." : "CLOCK IN"}
                  </button>
                </div>
              )}

              {/* STATE 2: CURRENTLY WORKING */}
              {isWorking && (
                <div className="space-y-6 my-auto">
                  <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-4">
                    <div className="flex items-center gap-2">
                      <span className="w-3 h-3 rounded-full bg-emerald-500 animate-ping"></span>
                      <span className="text-xs font-black tracking-widest text-emerald-600 dark:text-emerald-400 uppercase">
                        YOU ARE CURRENTLY WORKING
                      </span>
                    </div>

                    <span
                      className={`px-3 py-1 rounded-full text-xs font-bold ${
                        attendance.arrivalStatus === "EARLY"
                          ? "bg-blue-500/10 text-blue-500 border border-blue-500/20"
                          : attendance.arrivalStatus === "LATE"
                          ? "bg-amber-500/10 text-amber-500 border border-amber-500/20"
                          : "bg-emerald-500/10 text-emerald-500 border border-emerald-500/20"
                      }`}
                    >
                      Arrival: {attendance.notes || attendance.arrivalStatus}
                    </span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="p-4 bg-slate-50 dark:bg-slate-950 rounded-xl border border-slate-100 dark:border-slate-800">
                      <span className="text-xs font-medium text-slate-500">Clock In Time</span>
                      <p className="text-lg font-black text-slate-900 dark:text-white mt-0.5">
                        {clockInFormatted}
                      </p>
                    </div>

                    <div className="p-4 bg-slate-50 dark:bg-slate-950 rounded-xl border border-slate-100 dark:border-slate-800">
                      <span className="text-xs font-medium text-slate-500">Active Break Status</span>
                      <p className="text-sm font-bold mt-0.5 text-slate-800 dark:text-slate-200">
                        {activeBreak ? "☕ Currently On Break" : "💼 Active Working Session"}
                      </p>
                    </div>
                  </div>

                  {/* LIVE TIMER DISPLAY */}
                  <div className="text-center py-4 bg-amber-50/50 dark:bg-amber-950/30 rounded-2xl border border-amber-100 dark:border-amber-900/50 p-6">
                    <span className="text-xs font-bold uppercase tracking-wider text-amber-500">
                      Live Working Duration
                    </span>
                    <div className="mt-2">
                      <Timer
                        clockInIso={attendance.clockIn}
                        totalBreakSeconds={todayData.totalBreakSeconds || 0}
                        activeBreakStartIso={activeBreak?.startTime || null}
                        isWorking={true}
                      />
                    </div>
                  </div>

                  {/* ACTION BUTTONS: BREAK & CLOCK OUT */}
                  <div className="flex flex-col sm:flex-row gap-4 pt-2">
                    {activeBreak ? (
                      <button
                        onClick={handleEndBreak}
                        disabled={actionLoading}
                        className="flex-1 py-3.5 px-4 bg-amber-600 hover:bg-amber-500 text-white font-bold rounded-xl shadow-lg shadow-amber-600/20 flex items-center justify-center gap-2 transition cursor-pointer disabled:opacity-50"
                      >
                        <Square className="w-4 h-4 fill-current" />
                        <span>END BREAK</span>
                      </button>
                    ) : (
                      <button
                        onClick={handleStartBreak}
                        disabled={actionLoading}
                        className="flex-1 py-3.5 px-4 bg-slate-800 hover:bg-slate-700 text-white font-bold rounded-xl border border-slate-700 flex items-center justify-center gap-2 transition cursor-pointer disabled:opacity-50"
                      >
                        <Coffee className="w-4 h-4" />
                        <span>START BREAK</span>
                      </button>
                    )}

                    <button
                      onClick={handleClockOut}
                      disabled={actionLoading}
                      className="flex-1 py-3.5 px-4 bg-rose-600 hover:bg-rose-500 text-white font-bold rounded-xl shadow-lg shadow-rose-600/30 flex items-center justify-center gap-2 transition cursor-pointer disabled:opacity-50"
                    >
                      <Square className="w-4 h-4 fill-current" />
                      <span>CLOCK OUT</span>
                    </button>
                  </div>
                </div>
              )}

              {/* STATE 3: COMPLETED WORKDAY */}
              {isCompleted && (
                <div className="space-y-6 my-auto">
                  <div className="flex items-center gap-2.5 p-3.5 bg-emerald-500/10 border border-emerald-500/30 rounded-xl text-emerald-600 dark:text-emerald-400">
                    <CheckCircle2 className="w-5 h-5 shrink-0" />
                    <span className="text-sm font-bold">
                      Workday Completed for Today!
                    </span>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                    <div className="p-4 bg-slate-50 dark:bg-slate-950 rounded-xl border border-slate-100 dark:border-slate-800">
                      <span className="text-xs text-slate-500 font-medium">Clock In</span>
                      <p className="text-base font-black text-slate-900 dark:text-white mt-1">
                        {clockInFormatted}
                      </p>
                    </div>

                    <div className="p-4 bg-slate-50 dark:bg-slate-950 rounded-xl border border-slate-100 dark:border-slate-800">
                      <span className="text-xs text-slate-500 font-medium">Clock Out</span>
                      <p className="text-base font-black text-slate-900 dark:text-white mt-1">
                        {clockOutFormatted}
                      </p>
                    </div>

                    <div className="p-4 bg-slate-50 dark:bg-slate-950 rounded-xl border border-slate-100 dark:border-slate-800">
                      <span className="text-xs text-slate-500 font-medium">Break Time</span>
                      <p className="text-base font-black text-slate-900 dark:text-white mt-1">
                        {Math.floor((attendance.breakSeconds || 0) / 3600)}h {Math.floor(((attendance.breakSeconds || 0) % 3600) / 60)}m
                      </p>
                    </div>

                    <div className="p-4 bg-amber-500/10 rounded-xl border border-amber-500/20">
                      <span className="text-xs text-amber-400 font-semibold">Actual Working</span>
                      <p className="text-base font-black text-amber-500 mt-1">
                        {Math.floor((attendance.actualWorkSeconds || 0) / 3600)}h {Math.floor(((attendance.actualWorkSeconds || 0) % 3600) / 60)}m
                      </p>
                    </div>
                  </div>

                  <p className="text-xs text-slate-500 dark:text-slate-400 text-center italic">
                    Your attendance record is safely recorded in the database.
                  </p>
                </div>
              )}
            </div>
          </div>

          {/* MONTHLY SUMMARY CARD & STATS */}
          {monthlySummary && (
            <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 sm:p-8 border border-slate-200 dark:border-slate-800 shadow-sm space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 dark:border-slate-800 pb-4">
                <div>
                  <h3 className="text-lg font-extrabold text-slate-900 dark:text-white tracking-tight flex items-center gap-2">
                    <BarChart3 className="w-5 h-5 text-amber-500" />
                    <span>Monthly Attendance Summary</span>
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400 font-medium mt-0.5">
                    {monthlySummary.monthName} Performance &amp; Hours
                  </p>
                </div>
                <span className="text-xs font-bold px-3 py-1 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-lg self-start sm:self-auto">
                  {monthlySummary.stats.workingDays} Scheduled Working Days
                </span>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
                <div className="p-4 bg-emerald-500/10 border border-emerald-500/20 rounded-2xl text-center">
                  <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400 uppercase tracking-wider">
                    Present
                  </span>
                  <p className="text-2xl sm:text-3xl font-black text-emerald-600 dark:text-emerald-400 mt-1">
                    {monthlySummary.stats.present}
                  </p>
                </div>

                <div className="p-4 bg-rose-500/10 border border-rose-500/20 rounded-2xl text-center">
                  <span className="text-xs font-bold text-rose-600 dark:text-rose-400 uppercase tracking-wider">
                    Absent
                  </span>
                  <p className="text-2xl sm:text-3xl font-black text-rose-600 dark:text-rose-400 mt-1">
                    {monthlySummary.stats.absent}
                  </p>
                </div>

                <div className="p-4 bg-amber-500/10 border border-amber-500/20 rounded-2xl text-center">
                  <span className="text-xs font-bold text-amber-600 dark:text-amber-400 uppercase tracking-wider">
                    Late
                  </span>
                  <p className="text-2xl sm:text-3xl font-black text-amber-600 dark:text-amber-400 mt-1">
                    {monthlySummary.stats.late}
                  </p>
                </div>

                <div className="p-4 bg-blue-500/10 border border-blue-500/20 rounded-2xl text-center">
                  <span className="text-xs font-bold text-blue-600 dark:text-blue-400 uppercase tracking-wider">
                    Early
                  </span>
                  <p className="text-2xl sm:text-3xl font-black text-blue-600 dark:text-blue-400 mt-1">
                    {monthlySummary.stats.early}
                  </p>
                </div>

                <div className="p-4 bg-amber-500/10 border border-amber-500/20 rounded-2xl text-center">
                  <span className="text-xs font-bold text-amber-600 dark:text-amber-400 uppercase tracking-wider">
                    Total Hours
                  </span>
                  <p className="text-lg sm:text-xl font-black text-amber-600 dark:text-amber-400 mt-1">
                    {monthlySummary.stats.totalHoursFormatted}
                  </p>
                </div>

                <div className="p-4 bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl text-center">
                  <span className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                    Avg Daily
                  </span>
                  <p className="text-lg sm:text-xl font-black text-slate-800 dark:text-slate-200 mt-1">
                    {monthlySummary.stats.avgHoursFormatted}
                  </p>
                </div>
              </div>
            </div>
          )}
        </main>
      </div>
    </div>
  );
}
