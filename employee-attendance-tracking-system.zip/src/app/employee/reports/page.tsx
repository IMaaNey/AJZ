"use client";

import { useEffect, useState } from "react";
import { Sidebar } from "@/components/Sidebar";
import { Header } from "@/components/Header";
import { BarChart3, TrendingUp, Clock, CheckCircle2, AlertCircle } from "lucide-react";
import { useRouter } from "next/navigation";

export default function EmployeeReportsPage() {
  const router = useRouter();
  const [user, setUser] = useState<any>(null);
  const [summary, setSummary] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [mobileNavOpen, setMobileNavOpen] = useState(false);

  useEffect(() => {
    async function loadData() {
      try {
        const uRes = await fetch("/api/auth/me");
        if (!uRes.ok) {
          router.push("/login");
          return;
        }
        const uData = await uRes.json();
        setUser(uData.user);

        const res = await fetch("/api/attendance/monthly-summary");
        if (res.ok) {
          const data = await res.json();
          setSummary(data);
        }
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    }
    loadData();
  }, [router]);

  const handleLogout = async () => {
    await fetch("/api/auth/logout", { method: "POST" });
    router.push("/login");
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex text-slate-800 dark:text-slate-100">
      <Sidebar
        role={user?.role || "EMPLOYEE"}
        userName={user?.fullName || "Employee"}
        userEmail={user?.email || ""}
        isOpenMobile={mobileNavOpen}
        onCloseMobile={() => setMobileNavOpen(false)}
        onLogout={handleLogout}
      />

      <div className="flex-1 lg:pl-64 flex flex-col min-w-0">
        <Header
          userName={user?.fullName || "Employee"}
          role={user?.role || "EMPLOYEE"}
          department={user?.department || "General"}
          onOpenMobileNav={() => setMobileNavOpen(true)}
        />

        <main className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto w-full space-y-6">
          <div>
            <h1 className="text-2xl font-black text-slate-900 dark:text-white tracking-tight flex items-center gap-2">
              <BarChart3 className="w-6 h-6 text-amber-500" />
              <span>My Reports &amp; Performance</span>
            </h1>
            <p className="text-sm text-slate-500 dark:text-slate-400 font-medium">
              Monthly breakdown of working hours, punctuality, and attendance stats.
            </p>
          </div>

          {loading ? (
            <div className="p-12 text-center text-slate-500">Loading reports...</div>
          ) : (
            <div className="space-y-6">
              {/* Stats Overview Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="p-6 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm">
                  <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
                    Total Hours Worked
                  </span>
                  <p className="text-3xl font-black text-amber-600 dark:text-amber-400 mt-2">
                    {summary?.stats?.totalHoursFormatted || "00h 00m"}
                  </p>
                  <p className="text-xs text-slate-400 mt-1">This month overall</p>
                </div>

                <div className="p-6 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm">
                  <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
                    Average Daily Hours
                  </span>
                  <p className="text-3xl font-black text-emerald-600 dark:text-emerald-400 mt-2">
                    {summary?.stats?.avgHoursFormatted || "00h 00m"}
                  </p>
                  <p className="text-xs text-slate-400 mt-1">Per present workday</p>
                </div>

                <div className="p-6 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm">
                  <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
                    Present Days
                  </span>
                  <p className="text-3xl font-black text-slate-900 dark:text-white mt-2">
                    {summary?.stats?.present || 0} / {summary?.stats?.workingDays || 0}
                  </p>
                  <p className="text-xs text-slate-400 mt-1">Workdays attended</p>
                </div>

                <div className="p-6 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm">
                  <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
                    Late Days
                  </span>
                  <p className="text-3xl font-black text-amber-500 mt-2">
                    {summary?.stats?.late || 0}
                  </p>
                  <p className="text-xs text-slate-400 mt-1">Arrival after grace period</p>
                </div>
              </div>

              {/* Attendance Ratio Bar */}
              <div className="p-6 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
                <h3 className="text-base font-bold text-slate-900 dark:text-white">
                  Attendance Breakdown
                </h3>
                {summary?.stats?.workingDays > 0 && (
                  <div className="space-y-3">
                    <div className="w-full h-4 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden flex">
                      <div
                        style={{
                          width: `${(summary.stats.onTime / summary.stats.workingDays) * 100}%`,
                        }}
                        className="bg-emerald-500 h-full"
                        title="On Time"
                      />
                      <div
                        style={{
                          width: `${(summary.stats.early / summary.stats.workingDays) * 100}%`,
                        }}
                        className="bg-blue-500 h-full"
                        title="Early"
                      />
                      <div
                        style={{
                          width: `${(summary.stats.late / summary.stats.workingDays) * 100}%`,
                        }}
                        className="bg-amber-500 h-full"
                        title="Late"
                      />
                      <div
                        style={{
                          width: `${(summary.stats.absent / summary.stats.workingDays) * 100}%`,
                        }}
                        className="bg-rose-500 h-full"
                        title="Absent"
                      />
                    </div>

                    <div className="flex flex-wrap items-center gap-4 text-xs font-bold text-slate-600 dark:text-slate-400">
                      <span className="flex items-center gap-1.5">
                        <span className="w-3 h-3 rounded-full bg-emerald-500"></span>
                        On Time: {summary.stats.onTime}
                      </span>
                      <span className="flex items-center gap-1.5">
                        <span className="w-3 h-3 rounded-full bg-blue-500"></span>
                        Early: {summary.stats.early}
                      </span>
                      <span className="flex items-center gap-1.5">
                        <span className="w-3 h-3 rounded-full bg-amber-500"></span>
                        Late: {summary.stats.late}
                      </span>
                      <span className="flex items-center gap-1.5">
                        <span className="w-3 h-3 rounded-full bg-rose-500"></span>
                        Absent: {summary.stats.absent}
                      </span>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}
        </main>
      </div>
    </div>
  );
}
