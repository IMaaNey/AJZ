"use client";

import { useEffect, useState, useCallback } from "react";
import { Sidebar } from "@/components/Sidebar";
import { Header } from "@/components/Header";
import { Calendar as CalendarIcon, ChevronLeft, ChevronRight, X, Clock } from "lucide-react";
import { useRouter } from "next/navigation";

export default function EmployeeCalendarPage() {
  const router = useRouter();
  const [user, setUser] = useState<any>(null);
  const [calendarData, setCalendarData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [selectedDay, setSelectedDay] = useState<any>(null);
  const [year, setYear] = useState<number>(new Date().getFullYear());
  const [month, setMonth] = useState<number>(new Date().getMonth() + 1);
  const [mobileNavOpen, setMobileNavOpen] = useState(false);

  const fetchCalendar = useCallback(async () => {
    setLoading(true);
    try {
      const uRes = await fetch("/api/auth/me");
      if (!uRes.ok) {
        router.push("/login");
        return;
      }
      const uData = await uRes.json();
      setUser(uData.user);

      const res = await fetch(`/api/attendance/calendar?year=${year}&month=${month}`);
      if (res.ok) {
        const data = await res.json();
        setCalendarData(data);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  }, [year, month, router]);

  useEffect(() => {
    fetchCalendar();
  }, [fetchCalendar]);

  const handlePrevMonth = () => {
    if (month === 1) {
      setMonth(12);
      setYear((y) => y - 1);
    } else {
      setMonth((m) => m - 1);
    }
  };

  const handleNextMonth = () => {
    if (month === 12) {
      setMonth(1);
      setYear((y) => y + 1);
    } else {
      setMonth((m) => m + 1);
    }
  };

  const handleLogout = async () => {
    await fetch("/api/auth/logout", { method: "POST" });
    router.push("/login");
  };

  const monthNames = [
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"
  ];

  const badgeStyles: Record<string, string> = {
    PRESENT: "bg-emerald-500/10 text-emerald-500 border-emerald-500/20",
    EARLY: "bg-blue-500/10 text-blue-500 border-blue-500/20",
    LATE: "bg-amber-500/10 text-amber-500 border-amber-500/20",
    ABSENT: "bg-rose-500/10 text-rose-500 border-rose-500/20",
    HOLIDAY: "bg-slate-500/10 text-slate-400 border-slate-500/20",
    LEAVE: "bg-purple-500/10 text-purple-400 border-purple-500/20",
    WEEKEND: "bg-slate-100 dark:bg-slate-800 text-slate-400 border-transparent",
    NONE: "bg-transparent text-slate-400 border-transparent",
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex text-slate-800 dark:text-slate-100">
      <Sidebar
        role={user?.role || "EMPLOYEE"}
        userName={user?.fullName || "Employee"}
        userEmail={user?.email || ""}
        isOpenMobile={mobileNavOpen}
        onCloseMobile={() => setMobileNavOpen(false)}
        onLogout={handleLogout}
      />

      <div className="flex-1 lg:pl-64 flex flex-col min-w-0">
        <Header
          userName={user?.fullName || "Employee"}
          role={user?.role || "EMPLOYEE"}
          department={user?.department || "General"}
          onOpenMobileNav={() => setMobileNavOpen(true)}
        />

        <main className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto w-full space-y-6">
          {/* Top Month Header */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 sm:p-6 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h1 className="text-2xl font-black text-slate-900 dark:text-white tracking-tight flex items-center gap-2">
                <CalendarIcon className="w-6 h-6 text-amber-500" />
                <span>My Attendance Calendar</span>
              </h1>
              <p className="text-sm text-slate-500 dark:text-slate-400 font-medium">
                {monthNames[month - 1]} {year} Grid Status
              </p>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={handlePrevMonth}
                className="p-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 transition cursor-pointer"
              >
                <ChevronLeft className="w-5 h-5" />
              </button>

              <span className="text-base font-extrabold px-4 py-2 bg-slate-50 dark:bg-slate-950 rounded-xl border border-slate-200 dark:border-slate-800 text-slate-800 dark:text-slate-200">
                {monthNames[month - 1]} {year}
              </span>

              <button
                onClick={handleNextMonth}
                className="p-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 transition cursor-pointer"
              >
                <ChevronRight className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Calendar Status Legend */}
          <div className="flex flex-wrap items-center gap-3 text-xs font-semibold p-4 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800">
            <span className="text-slate-500 font-bold uppercase tracking-wider">Legend:</span>
            <span className="px-2.5 py-1 rounded-md bg-emerald-500/10 text-emerald-500 border border-emerald-500/20">🟢 Present</span>
            <span className="px-2.5 py-1 rounded-md bg-blue-500/10 text-blue-500 border border-blue-500/20">🔵 Early</span>
            <span className="px-2.5 py-1 rounded-md bg-amber-500/10 text-amber-500 border border-amber-500/20">🟡 Late</span>
            <span className="px-2.5 py-1 rounded-md bg-rose-500/10 text-rose-500 border border-rose-500/20">🔴 Absent</span>
            <span className="px-2.5 py-1 rounded-md bg-slate-500/10 text-slate-400 border border-slate-500/20">⚪ Holiday</span>
            <span className="px-2.5 py-1 rounded-md bg-purple-500/10 text-purple-400 border border-purple-500/20">🟣 Leave</span>
          </div>

          {/* Calendar Grid */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 sm:p-6 border border-slate-200 dark:border-slate-800 shadow-sm">
            {loading ? (
              <div className="p-12 text-center text-slate-500">Loading calendar data...</div>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-7 gap-3">
                {calendarData?.days?.map((day: any) => (
                  <button
                    key={day.date}
                    onClick={() => setSelectedDay(day)}
                    className={`p-3.5 rounded-2xl border text-left flex flex-col justify-between h-28 transition-all hover:scale-102 cursor-pointer ${
                      badgeStyles[day.status] || "bg-slate-50 dark:bg-slate-950 border-slate-200 dark:border-slate-800"
                    }`}
                  >
                    <div className="flex items-center justify-between w-full">
                      <span className="text-base font-black">{day.dayNumber}</span>
                      <span className="text-[10px] font-bold uppercase opacity-75">{day.dayName.slice(0, 3)}</span>
                    </div>

                    <div className="mt-auto">
                      <span className="text-xs font-bold block truncate">
                        {day.status === "PRESENT" && "🟢 Present"}
                        {day.status === "EARLY" && "🔵 Early"}
                        {day.status === "LATE" && "🟡 Late"}
                        {day.status === "ABSENT" && "🔴 Absent"}
                        {day.status === "HOLIDAY" && "⚪ Holiday"}
                        {day.status === "LEAVE" && "🟣 Leave"}
                        {day.status === "WEEKEND" && "Weekend"}
                        {day.status === "NONE" && "—"}
                      </span>
                      {day.holidayName && (
                        <span className="text-[10px] opacity-80 block truncate mt-0.5">
                          {day.holidayName}
                        </span>
                      )}
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>
        </main>
      </div>

      {/* Date Detail Modal */}
      {selectedDay && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-xs">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 max-w-md w-full shadow-2xl text-slate-200 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div>
                <h3 className="text-lg font-black text-white">
                  {selectedDay.date} ({selectedDay.dayName})
                </h3>
                <p className="text-xs text-amber-400 font-semibold">Attendance Record Details</p>
              </div>
              <button
                onClick={() => setSelectedDay(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3">
              <div className="flex items-center justify-between p-3 bg-slate-950 rounded-xl border border-slate-800">
                <span className="text-xs font-medium text-slate-400">Day Status</span>
                <span className="text-sm font-bold text-white">{selectedDay.status}</span>
              </div>

              {selectedDay.attendance ? (
                <>
                  <div className="flex items-center justify-between p-3 bg-slate-950 rounded-xl border border-slate-800">
                    <span className="text-xs font-medium text-slate-400">Clock In</span>
                    <span className="text-sm font-bold text-white font-mono">
                      {new Date(selectedDay.attendance.clockIn).toLocaleTimeString("en-US", {
                        timeZone: "Asia/Karachi",
                        hour: "2-digit",
                        minute: "2-digit",
                        hour12: true,
                      })}
                    </span>
                  </div>

                  <div className="flex items-center justify-between p-3 bg-slate-950 rounded-xl border border-slate-800">
                    <span className="text-xs font-medium text-slate-400">Clock Out</span>
                    <span className="text-sm font-bold text-white font-mono">
                      {selectedDay.attendance.clockOut
                        ? new Date(selectedDay.attendance.clockOut).toLocaleTimeString("en-US", {
                            timeZone: "Asia/Karachi",
                            hour: "2-digit",
                            minute: "2-digit",
                            hour12: true,
                          })
                        : "—"}
                    </span>
                  </div>

                  <div className="flex items-center justify-between p-3 bg-slate-950 rounded-xl border border-slate-800">
                    <span className="text-xs font-medium text-slate-400">Arrival Status</span>
                    <span className="text-xs font-bold text-emerald-400">
                      {selectedDay.attendance.notes || selectedDay.attendance.arrivalStatus}
                    </span>
                  </div>

                  <div className="flex items-center justify-between p-3 bg-slate-950 rounded-xl border border-slate-800">
                    <span className="text-xs font-medium text-slate-400">Working Hours</span>
                    <span className="text-sm font-black text-amber-400">
                      {Math.floor(selectedDay.attendance.actualWorkSeconds / 3600)}h{" "}
                      {Math.floor((selectedDay.attendance.actualWorkSeconds % 3600) / 60)}m
                    </span>
                  </div>
                </>
              ) : (
                <p className="text-xs text-slate-400 p-3 bg-slate-950 rounded-xl border border-slate-800 italic">
                  {selectedDay.holidayName
                    ? `Company Holiday: ${selectedDay.holidayName}`
                    : selectedDay.leaveReason
                    ? `Approved Leave: ${selectedDay.leaveReason}`
                    : selectedDay.isWorkingDay
                    ? "No clock in record registered for this day."
                    : "Non-working day / weekend."}
                </p>
              )}
            </div>

            <div className="pt-2 flex justify-end">
              <button
                onClick={() => setSelectedDay(null)}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-xl text-xs font-bold transition"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
