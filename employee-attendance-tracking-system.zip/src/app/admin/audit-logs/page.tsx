"use client";

import { useEffect, useState } from "react";
import { Sidebar } from "@/components/Sidebar";
import { Header } from "@/components/Header";
import { ShieldAlert, Clock, User, Info } from "lucide-react";
import { useRouter } from "next/navigation";

export default function AdminAuditLogsPage() {
  const router = useRouter();
  const [user, setUser] = useState<any>(null);
  const [logs, setLogs] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [mobileNavOpen, setMobileNavOpen] = useState(false);

  useEffect(() => {
    async function loadLogs() {
      try {
        const uRes = await fetch("/api/auth/me");
        if (!uRes.ok) {
          router.push("/login");
          return;
        }
        const uData = await uRes.json();
        if (uData.user?.role !== "ADMIN") {
          router.push("/employee/dashboard");
          return;
        }
        setUser(uData.user);

        const lRes = await fetch("/api/admin/audit-logs");
        if (lRes.ok) {
          const lData = await lRes.json();
          setLogs(lData.auditLogs || []);
        }
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    }
    loadLogs();
  }, [router]);

  const handleLogout = async () => {
    await fetch("/api/auth/logout", { method: "POST" });
    router.push("/login");
  };

  const formatTimestamp = (ts: string) => {
    return new Date(ts).toLocaleString("en-US", {
      timeZone: "Asia/Karachi",
      year: "numeric",
      month: "short",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
      hour12: true,
    });
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex text-slate-800 dark:text-slate-100">
      <Sidebar
        role="ADMIN"
        userName={user?.fullName || "Admin"}
        userEmail={user?.email || ""}
        isOpenMobile={mobileNavOpen}
        onCloseMobile={() => setMobileNavOpen(false)}
        onLogout={handleLogout}
      />

      <div className="flex-1 lg:pl-64 flex flex-col min-w-0">
        <Header
          userName={user?.fullName || "Admin"}
          role="ADMIN"
          department="Management"
          onOpenMobileNav={() => setMobileNavOpen(true)}
        />

        <main className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto w-full space-y-6">
          <div>
            <h1 className="text-2xl font-black text-slate-900 dark:text-white tracking-tight flex items-center gap-2">
              <ShieldAlert className="w-6 h-6 text-amber-500" />
              <span>System Audit Logs</span>
            </h1>
            <p className="text-sm text-slate-500 dark:text-slate-400 font-medium">
              Complete security audit trail of employee registrations, attendance edits, password resets, and settings changes.
            </p>
          </div>

          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
            {loading ? (
              <div className="p-8 text-center text-slate-500">Loading audit logs...</div>
            ) : logs.length === 0 ? (
              <div className="p-12 text-center text-slate-500">No audit logs found.</div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-sm">
                  <thead className="bg-slate-50 dark:bg-slate-950 text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 border-b border-slate-200 dark:border-slate-800">
                    <tr>
                      <th className="py-3.5 px-4">Date &amp; Time (PKT)</th>
                      <th className="py-3.5 px-4">Admin User</th>
                      <th className="py-3.5 px-4">Action</th>
                      <th className="py-3.5 px-4">Target Entity</th>
                      <th className="py-3.5 px-4">Details</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800 font-medium">
                    {logs.map((log) => (
                      <tr key={log.id} className="hover:bg-slate-50/80 dark:hover:bg-slate-850/50 transition">
                        <td className="py-3.5 px-4 text-xs font-mono font-bold text-slate-600 dark:text-slate-300">
                          {formatTimestamp(log.createdAt)}
                        </td>
                        <td className="py-3.5 px-4 font-bold text-slate-900 dark:text-white">
                          {log.adminName}
                        </td>
                        <td className="py-3.5 px-4">
                          <span className="px-2.5 py-0.5 rounded-full text-[10px] font-extrabold uppercase tracking-wider bg-slate-100 dark:bg-slate-800 text-amber-500 border border-slate-200 dark:border-slate-700">
                            {log.action}
                          </span>
                        </td>
                        <td className="py-3.5 px-4 text-xs font-bold text-slate-700 dark:text-slate-200">
                          {log.target}
                        </td>
                        <td className="py-3.5 px-4 text-xs text-slate-500">
                          {log.details || "—"}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </main>
      </div>
    </div>
  );
}
