"use client";

import { useEffect, useState, useCallback } from "react";
import { Sidebar } from "@/components/Sidebar";
import { Header } from "@/components/Header";
import { Calendar as CalendarIcon, ChevronLeft, ChevronRight, X } from "lucide-react";
import { useRouter } from "next/navigation";

export default function AdminCalendarPage() {
  const router = useRouter();
  const [user, setUser] = useState<any>(null);
  const [employees, setEmployees] = useState<any[]>([]);
  const [selectedEmpId, setSelectedEmpId] = useState<string>("");
  const [calendarData, setCalendarData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [selectedDay, setSelectedDay] = useState<any>(null);
  const [year, setYear] = useState<number>(new Date().getFullYear());
  const [month, setMonth] = useState<number>(new Date().getMonth() + 1);
  const [mobileNavOpen, setMobileNavOpen] = useState(false);

  const fetchCalendar = useCallback(async () => {
    setLoading(true);
    try {
      const uRes = await fetch("/api/auth/me");
      if (!uRes.ok) {
        router.push("/login");
        return;
      }
      const uData = await uRes.json();
      if (uData.user?.role !== "ADMIN") {
        router.push("/employee/dashboard");
        return;
      }
      setUser(uData.user);

      // Fetch employees list
      const empRes = await fetch("/api/admin/employees");
      if (empRes.ok) {
        const empData = await empRes.json();
        const empList = empData.employees || [];
        setEmployees(empList);

        const targetEmpId = selectedEmpId || (empList.length > 0 ? empList[0].id : "");
        if (targetEmpId) {
          const calRes = await fetch(
            `/api/attendance/calendar?employeeId=${targetEmpId}&year=${year}&month=${month}`
          );
          if (calRes.ok) {
            const data = await calRes.json();
            setCalendarData(data);
          }
        }
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  }, [selectedEmpId, year, month, router]);

  useEffect(() => {
    fetchCalendar();
  }, [fetchCalendar]);

  const handlePrevMonth = () => {
    if (month === 1) {
      setMonth(12);
      setYear((y) => y - 1);
    } else {
      setMonth((m) => m - 1);
    }
  };

  const handleNextMonth = () => {
    if (month === 12) {
      setMonth(1);
      setYear((y) => y + 1);
    } else {
      setMonth((m) => m + 1);
    }
  };

  const handleLogout = async () => {
    await fetch("/api/auth/logout", { method: "POST" });
    router.push("/login");
  };

  const monthNames = [
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"
  ];

  const badgeStyles: Record<string, string> = {
    PRESENT: "bg-emerald-500/10 text-emerald-500 border-emerald-500/20",
    EARLY: "bg-blue-500/10 text-blue-500 border-blue-500/20",
    LATE: "bg-amber-500/10 text-amber-500 border-amber-500/20",
    ABSENT: "bg-rose-500/10 text-rose-500 border-rose-500/20",
    HOLIDAY: "bg-slate-500/10 text-slate-400 border-slate-500/20",
    LEAVE: "bg-purple-500/10 text-purple-400 border-purple-500/20",
    WEEKEND: "bg-slate-100 dark:bg-slate-800 text-slate-400 border-transparent",
    NONE: "bg-transparent text-slate-400 border-transparent",
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex text-slate-800 dark:text-slate-100">
      <Sidebar
        role="ADMIN"
        userName={user?.fullName || "Admin"}
        userEmail={user?.email || ""}
        isOpenMobile={mobileNavOpen}
        onCloseMobile={() => setMobileNavOpen(false)}
        onLogout={handleLogout}
      />

      <div className="flex-1 lg:pl-64 flex flex-col min-w-0">
        <Header
          userName={user?.fullName || "Admin"}
          role="ADMIN"
          department="Management"
          onOpenMobileNav={() => setMobileNavOpen(true)}
        />

        <main className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto w-full space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h1 className="text-2xl font-black text-slate-900 dark:text-white tracking-tight flex items-center gap-2">
                <CalendarIcon className="w-6 h-6 text-amber-500" />
                <span>Company Attendance Calendar</span>
              </h1>
              <p className="text-sm text-slate-500 dark:text-slate-400 font-medium">
                View monthly attendance records for any employee across AJZ Consultants.
              </p>
            </div>

            <div className="flex items-center gap-3">
              <label className="text-xs font-bold text-slate-400">Select Employee:</label>
              <select
                value={selectedEmpId}
                onChange={(e) => setSelectedEmpId(e.target.value)}
                className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-800 dark:text-slate-200 focus:outline-hidden font-bold"
              >
                {employees.map((e) => (
                  <option key={e.id} value={e.id}>
                    {e.fullName} ({e.employeeCode})
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Month Navigator Header */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 sm:p-6 border border-slate-200 dark:border-slate-800 shadow-sm flex items-center justify-between">
            <button
              onClick={handlePrevMonth}
              className="p-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 transition"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>

            <span className="text-lg font-black text-slate-900 dark:text-white">
              {monthNames[month - 1]} {year}
            </span>

            <button
              onClick={handleNextMonth}
              className="p-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 transition"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>

          {/* Grid */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 sm:p-6 border border-slate-200 dark:border-slate-800 shadow-sm">
            {loading ? (
              <div className="p-12 text-center text-slate-500">Loading calendar data...</div>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-7 gap-3">
                {calendarData?.days?.map((day: any) => (
                  <button
                    key={day.date}
                    onClick={() => setSelectedDay(day)}
                    className={`p-3.5 rounded-2xl border text-left flex flex-col justify-between h-28 transition-all hover:scale-102 cursor-pointer ${
                      badgeStyles[day.status] || "bg-slate-50 dark:bg-slate-950 border-slate-200 dark:border-slate-800"
                    }`}
                  >
                    <div className="flex items-center justify-between w-full">
                      <span className="text-base font-black">{day.dayNumber}</span>
                      <span className="text-[10px] font-bold uppercase opacity-75">{day.dayName.slice(0, 3)}</span>
                    </div>

                    <div className="mt-auto">
                      <span className="text-xs font-bold block truncate">
                        {day.status === "PRESENT" && "🟢 Present"}
                        {day.status === "EARLY" && "🔵 Early"}
                        {day.status === "LATE" && "🟡 Late"}
                        {day.status === "ABSENT" && "🔴 Absent"}
                        {day.status === "HOLIDAY" && "⚪ Holiday"}
                        {day.status === "LEAVE" && "🟣 Leave"}
                        {day.status === "WEEKEND" && "Weekend"}
                      </span>
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>
        </main>
      </div>
    </div>
  );
}
