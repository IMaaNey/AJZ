"use client";

import { useEffect, useState, use } from "react";
import { Sidebar } from "@/components/Sidebar";
import { Header } from "@/components/Header";
import {
  User,
  Building2,
  Briefcase,
  Calendar,
  Clock,
  ArrowLeft,
  Mail,
  Phone,
  BarChart3,
} from "lucide-react";
import { useRouter } from "next/navigation";
import Link from "next/link";

export default function AdminEmployeeDetailPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const resolvedParams = use(params);
  const router = useRouter();
  const [user, setUser] = useState<any>(null);
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [mobileNavOpen, setMobileNavOpen] = useState(false);

  useEffect(() => {
    async function loadEmployeeData() {
      try {
        const uRes = await fetch("/api/auth/me");
        if (!uRes.ok) {
          router.push("/login");
          return;
        }
        const uData = await uRes.json();
        if (uData.user?.role !== "ADMIN") {
          router.push("/employee/dashboard");
          return;
        }
        setUser(uData.user);

        const res = await fetch(`/api/admin/employees/${resolvedParams.id}`);
        if (res.ok) {
          const empData = await res.json();
          setData(empData);
        }
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    }
    loadEmployeeData();
  }, [resolvedParams.id, router]);

  const handleLogout = async () => {
    await fetch("/api/auth/logout", { method: "POST" });
    router.push("/login");
  };

  const formatHours = (seconds: number) => {
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    return `${String(h).padStart(2, "0")}h ${String(m).padStart(2, "0")}m`;
  };

  const emp = data?.employee;
  const summary = data?.summary;
  const history = data?.attendanceHistory || [];

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex text-slate-800 dark:text-slate-100">
      <Sidebar
        role="ADMIN"
        userName={user?.fullName || "Admin"}
        userEmail={user?.email || ""}
        isOpenMobile={mobileNavOpen}
        onCloseMobile={() => setMobileNavOpen(false)}
        onLogout={handleLogout}
      />

      <div className="flex-1 lg:pl-64 flex flex-col min-w-0">
        <Header
          userName={user?.fullName || "Admin"}
          role="ADMIN"
          department="Management"
          onOpenMobileNav={() => setMobileNavOpen(true)}
        />

        <main className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto w-full space-y-6">
          <Link
            href="/admin/employees"
            className="inline-flex items-center gap-2 text-xs font-bold text-amber-500 hover:text-amber-400 transition"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Back to Employee Directory</span>
          </Link>

          {loading ? (
            <div className="p-12 text-center text-slate-500">Loading employee details...</div>
          ) : !emp ? (
            <div className="p-12 text-center text-slate-500">Employee not found.</div>
          ) : (
            <div className="space-y-6">
              {/* Profile Card Header */}
              <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 sm:p-8 border border-slate-200 dark:border-slate-800 shadow-sm space-y-6">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 dark:border-slate-800 pb-6">
                  <div className="flex items-center gap-4">
                    <div className="w-16 h-16 rounded-2xl bg-amber-600 text-white font-black text-2xl flex items-center justify-center shadow-lg shadow-amber-600/30">
                      {emp.fullName.charAt(0)}
                    </div>
                    <div>
                      <h1 className="text-2xl font-black text-slate-900 dark:text-white tracking-tight">
                        {emp.fullName}
                      </h1>
                      <p className="text-xs text-amber-500 font-bold mt-0.5">
                        Code: {emp.employeeCode} • {emp.designation}
                      </p>
                    </div>
                  </div>

                  <span
                    className={`px-3 py-1 rounded-full text-xs font-bold self-start sm:self-auto ${
                      emp.status === "ACTIVE"
                        ? "bg-emerald-500/10 text-emerald-500 border border-emerald-500/20"
                        : "bg-rose-500/10 text-rose-500 border border-rose-500/20"
                    }`}
                  >
                    {emp.status}
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 text-xs">
                  <div className="p-3.5 bg-slate-50 dark:bg-slate-950 rounded-xl border border-slate-200 dark:border-slate-800">
                    <span className="text-slate-400 font-bold block mb-1">Official Email</span>
                    <span className="font-bold text-slate-800 dark:text-slate-200">{emp.officialEmail}</span>
                  </div>

                  <div className="p-3.5 bg-slate-50 dark:bg-slate-950 rounded-xl border border-slate-200 dark:border-slate-800">
                    <span className="text-slate-400 font-bold block mb-1">Department</span>
                    <span className="font-bold text-slate-800 dark:text-slate-200">{emp.departmentName}</span>
                  </div>

                  <div className="p-3.5 bg-slate-50 dark:bg-slate-950 rounded-xl border border-slate-200 dark:border-slate-800">
                    <span className="text-slate-400 font-bold block mb-1">Joining Date</span>
                    <span className="font-bold text-slate-800 dark:text-slate-200">{emp.joiningDate}</span>
                  </div>

                  <div className="p-3.5 bg-slate-50 dark:bg-slate-950 rounded-xl border border-slate-200 dark:border-slate-800">
                    <span className="text-slate-400 font-bold block mb-1">Phone</span>
                    <span className="font-bold text-slate-800 dark:text-slate-200">{emp.phone || "—"}</span>
                  </div>
                </div>
              </div>

              {/* Monthly Stats */}
              <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
                <h3 className="text-sm font-bold text-slate-500 uppercase tracking-wider flex items-center gap-2">
                  <BarChart3 className="w-4 h-4 text-amber-500" />
                  <span>Current Month Performance Summary</span>
                </h3>

                <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
                  <div className="p-4 bg-emerald-500/10 rounded-xl text-center">
                    <span className="text-xs font-bold text-emerald-500 uppercase">Present</span>
                    <p className="text-2xl font-black text-emerald-500 mt-1">{summary?.present || 0}</p>
                  </div>

                  <div className="p-4 bg-amber-500/10 rounded-xl text-center">
                    <span className="text-xs font-bold text-amber-500 uppercase">Late</span>
                    <p className="text-2xl font-black text-amber-500 mt-1">{summary?.late || 0}</p>
                  </div>

                  <div className="p-4 bg-blue-500/10 rounded-xl text-center">
                    <span className="text-xs font-bold text-blue-500 uppercase">Early</span>
                    <p className="text-2xl font-black text-blue-500 mt-1">{summary?.early || 0}</p>
                  </div>

                  <div className="p-4 bg-emerald-500/10 rounded-xl text-center">
                    <span className="text-xs font-bold text-emerald-500 uppercase">On Time</span>
                    <p className="text-2xl font-black text-emerald-500 mt-1">{summary?.onTime || 0}</p>
                  </div>

                  <div className="p-4 bg-amber-500/10 rounded-xl text-center col-span-2 sm:col-span-1">
                    <span className="text-xs font-bold text-amber-500 uppercase">Total Hours</span>
                    <p className="text-xl font-black text-amber-500 mt-1">{summary?.totalHoursFormatted || "00h 00m"}</p>
                  </div>
                </div>
              </div>

              {/* Attendance History */}
              <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden p-6 space-y-4">
                <h3 className="text-base font-bold text-slate-900 dark:text-white">
                  Recent Attendance Logs
                </h3>

                {history.length === 0 ? (
                  <p className="text-xs text-slate-500 italic">No attendance records logged for this employee.</p>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-sm">
                      <thead className="bg-slate-50 dark:bg-slate-950 text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 border-b border-slate-200 dark:border-slate-800">
                        <tr>
                          <th className="py-3 px-4">Date</th>
                          <th className="py-3 px-4">Clock In</th>
                          <th className="py-3 px-4">Clock Out</th>
                          <th className="py-3 px-4">Break</th>
                          <th className="py-3 px-4">Working Hours</th>
                          <th className="py-3 px-4">Arrival Status</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-xs font-medium">
                        {history.map((r: any) => (
                          <tr key={r.id}>
                            <td className="py-3 px-4 font-bold text-slate-900 dark:text-white">{r.date}</td>
                            <td className="py-3 px-4 font-mono">
                              {new Date(r.clockIn).toLocaleTimeString("en-US", { timeZone: "Asia/Karachi", hour: "2-digit", minute: "2-digit", hour12: true })}
                            </td>
                            <td className="py-3 px-4 font-mono">
                              {r.clockOut
                                ? new Date(r.clockOut).toLocaleTimeString("en-US", { timeZone: "Asia/Karachi", hour: "2-digit", minute: "2-digit", hour12: true })
                                : "—"}
                            </td>
                            <td className="py-3 px-4">{formatHours(r.breakSeconds)}</td>
                            <td className="py-3 px-4 font-black text-amber-500">{formatHours(r.actualWorkSeconds)}</td>
                            <td className="py-3 px-4">
                              <span className="px-2 py-0.5 rounded-full font-bold bg-slate-100 dark:bg-slate-800">
                                {r.notes || r.arrivalStatus}
                              </span>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            </div>
          )}
        </main>
      </div>
    </div>
  );
}
