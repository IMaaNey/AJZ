"use client";

import { useEffect, useState, useCallback } from "react";
import { Sidebar } from "@/components/Sidebar";
import { Header } from "@/components/Header";
import { BarChart3, Download, Printer, Filter, Calendar } from "lucide-react";
import { useRouter } from "next/navigation";

export default function AdminReportsPage() {
  const router = useRouter();
  const [user, setUser] = useState<any>(null);
  const [employees, setEmployees] = useState<any[]>([]);
  const [reportData, setReportData] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [selectedDept, setSelectedDept] = useState("ALL");
  const [selectedEmp, setSelectedEmp] = useState("ALL");
  const [mobileNavOpen, setMobileNavOpen] = useState(false);

  const fetchReports = useCallback(async () => {
    setLoading(true);
    try {
      const uRes = await fetch("/api/auth/me");
      if (!uRes.ok) {
        router.push("/login");
        return;
      }
      const uData = await uRes.json();
      if (uData.user?.role !== "ADMIN") {
        router.push("/employee/dashboard");
        return;
      }
      setUser(uData.user);

      // Fetch employees dropdown list
      const empRes = await fetch("/api/admin/employees");
      if (empRes.ok) {
        const empData = await empRes.json();
        setEmployees(empData.employees || []);
      }

      const params = new URLSearchParams();
      if (startDate) params.set("startDate", startDate);
      if (endDate) params.set("endDate", endDate);
      if (selectedDept !== "ALL") params.set("department", selectedDept);
      if (selectedEmp !== "ALL") params.set("employeeId", selectedEmp);

      const res = await fetch(`/api/admin/reports?${params.toString()}`);
      if (res.ok) {
        const data = await res.json();
        setReportData(data);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  }, [startDate, endDate, selectedDept, selectedEmp, router]);

  useEffect(() => {
    fetchReports();
  }, [fetchReports]);

  const handleExportCSV = () => {
    if (!reportData?.reports || reportData.reports.length === 0) return;

    const headers = [
      "Employee Code",
      "Full Name",
      "Official Email",
      "Department",
      "Designation",
      "Scheduled Working Days",
      "Present Days",
      "Absent Days",
      "Late Days",
      "Early Days",
      "On Time Days",
      "Total Hours Worked",
      "Average Daily Hours",
    ];

    const rows = reportData.reports.map((r: any) => [
      `"${r.employeeCode}"`,
      `"${r.fullName}"`,
      `"${r.officialEmail}"`,
      `"${r.departmentName}"`,
      `"${r.designation}"`,
      r.workingDaysCount,
      r.presentCount,
      r.absentCount,
      r.lateCount,
      r.earlyCount,
      r.onTimeCount,
      `"${r.totalHoursFormatted}"`,
      `"${r.avgHoursFormatted}"`,
    ]);

    const csvContent =
      "data:text/csv;charset=utf-8," +
      [headers.join(","), ...rows.map((e: any) => e.join(","))].join("\n");

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute(
      "download",
      `AJZ_Consultants_Attendance_Report_${reportData.startDate}_to_${reportData.endDate}.csv`
    );
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleLogout = async () => {
    await fetch("/api/auth/logout", { method: "POST" });
    router.push("/login");
  };

  const reports = reportData?.reports || [];

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex text-slate-800 dark:text-slate-100">
      <Sidebar
        role="ADMIN"
        userName={user?.fullName || "Admin"}
        userEmail={user?.email || ""}
        isOpenMobile={mobileNavOpen}
        onCloseMobile={() => setMobileNavOpen(false)}
        onLogout={handleLogout}
      />

      <div className="flex-1 lg:pl-64 flex flex-col min-w-0">
        <Header
          userName={user?.fullName || "Admin"}
          role="ADMIN"
          department="Management"
          onOpenMobileNav={() => setMobileNavOpen(true)}
        />

        <main className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto w-full space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h1 className="text-2xl font-black text-slate-900 dark:text-white tracking-tight flex items-center gap-2">
                <BarChart3 className="w-6 h-6 text-amber-500" />
                <span>HR &amp; Attendance Reports</span>
              </h1>
              <p className="text-sm text-slate-500 dark:text-slate-400 font-medium">
                Generate and export detailed monthly and range-based employee working hour summaries.
              </p>
            </div>

            <div className="flex items-center gap-3 self-start sm:self-auto">
              <button
                onClick={handleExportCSV}
                disabled={reports.length === 0}
                className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold text-xs rounded-xl shadow-lg shadow-emerald-600/20 flex items-center gap-2 transition cursor-pointer disabled:opacity-50"
              >
                <Download className="w-4 h-4" />
                <span>Export CSV</span>
              </button>

              <button
                onClick={() => window.print()}
                className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-white font-extrabold text-xs rounded-xl flex items-center gap-2 transition cursor-pointer"
              >
                <Printer className="w-4 h-4" />
                <span>Print Report</span>
              </button>
            </div>
          </div>

          {/* Report Filters */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 shadow-xs grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-400 mb-1">Start Date</label>
              <input
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-800 dark:text-slate-200 focus:outline-hidden"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-400 mb-1">End Date</label>
              <input
                type="date"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
                className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-800 dark:text-slate-200 focus:outline-hidden"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-400 mb-1">Department</label>
              <select
                value={selectedDept}
                onChange={(e) => setSelectedDept(e.target.value)}
                className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-800 dark:text-slate-200 focus:outline-hidden"
              >
                <option value="ALL">All Departments</option>
                <option value="Engineering">Engineering</option>
                <option value="Human Resources">Human Resources</option>
                <option value="Sales & Marketing">Sales &amp; Marketing</option>
                <option value="Operations">Operations</option>
                <option value="Finance">Finance</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-400 mb-1">Employee</label>
              <select
                value={selectedEmp}
                onChange={(e) => setSelectedEmp(e.target.value)}
                className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-800 dark:text-slate-200 focus:outline-hidden"
              >
                <option value="ALL">All Staff</option>
                {employees.map((e) => (
                  <option key={e.id} value={e.id}>
                    {e.fullName} ({e.employeeCode})
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Report Table */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
            {loading ? (
              <div className="p-8 text-center text-slate-500">Generating report...</div>
            ) : reports.length === 0 ? (
              <div className="p-12 text-center text-slate-500">No report data found.</div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-sm">
                  <thead className="bg-slate-50 dark:bg-slate-950 text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 border-b border-slate-200 dark:border-slate-800">
                    <tr>
                      <th className="py-3.5 px-4">Employee</th>
                      <th className="py-3.5 px-4">Department</th>
                      <th className="py-3.5 px-4 text-center">Working Days</th>
                      <th className="py-3.5 px-4 text-center">Present</th>
                      <th className="py-3.5 px-4 text-center">Absent</th>
                      <th className="py-3.5 px-4 text-center">Late</th>
                      <th className="py-3.5 px-4 text-center">Early</th>
                      <th className="py-3.5 px-4 text-center">On Time</th>
                      <th className="py-3.5 px-4 text-right">Total Hours</th>
                      <th className="py-3.5 px-4 text-right">Avg Daily</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800 font-medium">
                    {reports.map((r: any) => (
                      <tr key={r.employeeId} className="hover:bg-slate-50/80 dark:hover:bg-slate-850/50 transition">
                        <td className="py-3.5 px-4">
                          <div>
                            <p className="font-bold text-slate-900 dark:text-white">{r.fullName}</p>
                            <p className="text-xs text-slate-500">{r.officialEmail}</p>
                          </div>
                        </td>
                        <td className="py-3.5 px-4 text-xs font-bold text-slate-600 dark:text-slate-300">
                          {r.departmentName}
                        </td>
                        <td className="py-3.5 px-4 text-center font-bold">{r.workingDaysCount}</td>
                        <td className="py-3.5 px-4 text-center font-black text-emerald-500">{r.presentCount}</td>
                        <td className="py-3.5 px-4 text-center font-black text-rose-500">{r.absentCount}</td>
                        <td className="py-3.5 px-4 text-center font-bold text-amber-500">{r.lateCount}</td>
                        <td className="py-3.5 px-4 text-center font-bold text-blue-500">{r.earlyCount}</td>
                        <td className="py-3.5 px-4 text-center font-bold text-emerald-500">{r.onTimeCount}</td>
                        <td className="py-3.5 px-4 text-right font-black text-amber-600 dark:text-amber-400">
                          {r.totalHoursFormatted}
                        </td>
                        <td className="py-3.5 px-4 text-right font-bold text-slate-700 dark:text-slate-300">
                          {r.avgHoursFormatted}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </main>
      </div>
    </div>
  );
}
