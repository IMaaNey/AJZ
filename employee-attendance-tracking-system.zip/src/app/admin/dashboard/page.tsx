"use client";

import { useEffect, useState, useCallback } from "react";
import { Sidebar } from "@/components/Sidebar";
import { Header } from "@/components/Header";
import {
  Users,
  UserCheck,
  Briefcase,
  Clock,
  UserX,
  TrendingUp,
  Search,
  Filter,
  BarChart3,
  Calendar,
  AlertCircle,
  Eye,
  Edit,
} from "lucide-react";
import { useRouter } from "next/navigation";
import Link from "next/link";

export default function AdminDashboard() {
  const router = useRouter();
  const [user, setUser] = useState<any>(null);
  const [dashData, setDashData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [deptFilter, setDeptFilter] = useState("ALL");
  const [statusFilter, setStatusFilter] = useState("ALL");
  const [mobileNavOpen, setMobileNavOpen] = useState(false);

  const fetchDashboard = useCallback(async () => {
    try {
      const uRes = await fetch("/api/auth/me");
      if (!uRes.ok) {
        router.push("/login");
        return;
      }
      const uData = await uRes.json();
      if (uData.user?.role !== "ADMIN") {
        router.push("/employee/dashboard");
        return;
      }
      setUser(uData.user);

      const dRes = await fetch("/api/admin/dashboard");
      if (dRes.ok) {
        const data = await dRes.json();
        setDashData(data);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  }, [router]);

  useEffect(() => {
    fetchDashboard();
  }, [fetchDashboard]);

  const handleLogout = async () => {
    await fetch("/api/auth/logout", { method: "POST" });
    router.push("/login");
  };

  const formatTime = (ts: string | null) => {
    if (!ts) return "—";
    return new Date(ts).toLocaleTimeString("en-US", {
      timeZone: "Asia/Karachi",
      hour: "2-digit",
      minute: "2-digit",
      hour12: true,
    });
  };

  let todayList = dashData?.todayAttendance || [];
  if (search) {
    const s = search.toLowerCase();
    todayList = todayList.filter(
      (item: any) =>
        item.employeeName.toLowerCase().includes(s) ||
        item.officialEmail.toLowerCase().includes(s) ||
        item.department.toLowerCase().includes(s)
    );
  }
  if (deptFilter !== "ALL") {
    todayList = todayList.filter((item: any) => item.department === deptFilter);
  }
  if (statusFilter !== "ALL") {
    todayList = todayList.filter((item: any) => item.attendanceStatus === statusFilter);
  }

  const stats = dashData?.stats || {
    totalEmployees: 0,
    presentToday: 0,
    currentlyWorking: 0,
    lateToday: 0,
    absentToday: 0,
    averageWorkingHoursFormatted: "00h 00m",
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex text-slate-800 dark:text-slate-100">
      <Sidebar
        role="ADMIN"
        userName={user?.fullName || "Admin"}
        userEmail={user?.email || ""}
        isOpenMobile={mobileNavOpen}
        onCloseMobile={() => setMobileNavOpen(false)}
        onLogout={handleLogout}
      />

      <div className="flex-1 lg:pl-64 flex flex-col min-w-0">
        <Header
          userName={user?.fullName || "Admin"}
          role="ADMIN"
          department="Management"
          onOpenMobileNav={() => setMobileNavOpen(true)}
        />

        <main className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto w-full space-y-8">
          {/* Header Banner */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h1 className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white tracking-tight">
                HRMS Admin Dashboard
              </h1>
              <p className="text-sm text-slate-500 dark:text-slate-400 font-medium">
                Live attendance monitoring &amp; statistics for AJZ Consultants.
              </p>
            </div>
            <div className="flex items-center gap-3">
              <Link
                href="/admin/employees"
                className="px-4 py-2.5 bg-amber-600 hover:bg-amber-500 text-white font-bold text-xs rounded-xl shadow-lg shadow-amber-600/20 transition cursor-pointer"
              >
                + Register Employee
              </Link>
              <Link
                href="/admin/attendance"
                className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs rounded-xl transition cursor-pointer"
              >
                Attendance Logs
              </Link>
            </div>
          </div>

          {/* REAL STATS CARDS GRID */}
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
            <div className="p-5 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-2">
              <div className="flex items-center justify-between text-slate-400">
                <span className="text-xs font-bold uppercase tracking-wider">Total Staff</span>
                <Users className="w-4 h-4 text-amber-500" />
              </div>
              <p className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white">
                {stats.totalEmployees}
              </p>
            </div>

            <div className="p-5 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-2">
              <div className="flex items-center justify-between text-slate-400">
                <span className="text-xs font-bold uppercase tracking-wider">Present</span>
                <UserCheck className="w-4 h-4 text-emerald-500" />
              </div>
              <p className="text-2xl sm:text-3xl font-black text-emerald-600 dark:text-emerald-400">
                {stats.presentToday}
              </p>
            </div>

            <div className="p-5 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-2">
              <div className="flex items-center justify-between text-slate-400">
                <span className="text-xs font-bold uppercase tracking-wider">Working Now</span>
                <Briefcase className="w-4 h-4 text-blue-500" />
              </div>
              <p className="text-2xl sm:text-3xl font-black text-blue-600 dark:text-blue-400">
                {stats.currentlyWorking}
              </p>
            </div>

            <div className="p-5 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-2">
              <div className="flex items-center justify-between text-slate-400">
                <span className="text-xs font-bold uppercase tracking-wider">Late Today</span>
                <Clock className="w-4 h-4 text-amber-500" />
              </div>
              <p className="text-2xl sm:text-3xl font-black text-amber-600 dark:text-amber-400">
                {stats.lateToday}
              </p>
            </div>

            <div className="p-5 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-2">
              <div className="flex items-center justify-between text-slate-400">
                <span className="text-xs font-bold uppercase tracking-wider">Absent Today</span>
                <UserX className="w-4 h-4 text-rose-500" />
              </div>
              <p className="text-2xl sm:text-3xl font-black text-rose-600 dark:text-rose-400">
                {stats.absentToday}
              </p>
            </div>

            <div className="p-5 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-2">
              <div className="flex items-center justify-between text-slate-400">
                <span className="text-xs font-bold uppercase tracking-wider">Avg Hours</span>
                <TrendingUp className="w-4 h-4 text-purple-500" />
              </div>
              <p className="text-xl sm:text-2xl font-black text-purple-600 dark:text-purple-400">
                {stats.averageWorkingHoursFormatted}
              </p>
            </div>
          </div>

          {/* TODAY'S ATTENDANCE TABLE CARD */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-4 p-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 dark:border-slate-800 pb-4">
              <div>
                <h2 className="text-lg font-extrabold text-slate-900 dark:text-white tracking-tight flex items-center gap-2">
                  <Clock className="w-5 h-5 text-amber-500" />
                  <span>Today&apos;s Attendance ({dashData?.date || "Today"})</span>
                </h2>
                <p className="text-xs text-slate-500 dark:text-slate-400 font-medium">
                  Real-time clock-in logs for today.
                </p>
              </div>

              {/* Filters */}
              <div className="flex flex-wrap items-center gap-2">
                <div className="relative">
                  <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
                  <input
                    type="text"
                    placeholder="Search employee..."
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                    className="pl-9 pr-3 py-1.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl text-xs text-slate-800 dark:text-slate-200 focus:outline-hidden focus:ring-2 focus:ring-amber-500"
                  />
                </div>

                <select
                  value={deptFilter}
                  onChange={(e) => setDeptFilter(e.target.value)}
                  className="bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl px-3 py-1.5 text-xs text-slate-800 dark:text-slate-200 focus:outline-hidden"
                >
                  <option value="ALL">All Depts</option>
                  <option value="Engineering">Engineering</option>
                  <option value="Human Resources">HR</option>
                  <option value="Sales & Marketing">Sales</option>
                  <option value="Operations">Operations</option>
                  <option value="Finance">Finance</option>
                </select>

                <select
                  value={statusFilter}
                  onChange={(e) => setStatusFilter(e.target.value)}
                  className="bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl px-3 py-1.5 text-xs text-slate-800 dark:text-slate-200 focus:outline-hidden"
                >
                  <option value="ALL">All Statuses</option>
                  <option value="WORKING">Working</option>
                  <option value="COMPLETED">Completed</option>
                </select>
              </div>
            </div>

            {loading ? (
              <div className="p-8 text-center text-slate-500">Loading today&apos;s records...</div>
            ) : todayList.length === 0 ? (
              <div className="p-8 text-center text-slate-500 text-sm">
                No attendance logs found for today.
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-sm">
                  <thead className="bg-slate-50 dark:bg-slate-950 text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 border-b border-slate-200 dark:border-slate-800">
                    <tr>
                      <th className="py-3.5 px-4">Employee</th>
                      <th className="py-3.5 px-4">Department</th>
                      <th className="py-3.5 px-4">Clock In</th>
                      <th className="py-3.5 px-4">Clock Out</th>
                      <th className="py-3.5 px-4">Working Hours</th>
                      <th className="py-3.5 px-4">Arrival Status</th>
                      <th className="py-3.5 px-4">Current Status</th>
                      <th className="py-3.5 px-4 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800 font-medium">
                    {todayList.map((item: any) => (
                      <tr key={item.id} className="hover:bg-slate-50/80 dark:hover:bg-slate-850/50 transition">
                        <td className="py-3.5 px-4">
                          <div>
                            <p className="font-bold text-slate-900 dark:text-white">
                              {item.employeeName}
                            </p>
                            <p className="text-xs text-slate-500">{item.officialEmail}</p>
                          </div>
                        </td>
                        <td className="py-3.5 px-4 text-xs font-bold text-slate-600 dark:text-slate-300">
                          {item.department}
                        </td>
                        <td className="py-3.5 px-4 font-mono">{formatTime(item.clockIn)}</td>
                        <td className="py-3.5 px-4 font-mono">{formatTime(item.clockOut)}</td>
                        <td className="py-3.5 px-4 font-black text-amber-600 dark:text-amber-400">
                          {item.workingHoursFormatted}
                        </td>
                        <td className="py-3.5 px-4">
                          <span
                            className={`px-2.5 py-0.5 rounded-full text-xs font-bold ${
                              item.arrivalStatus === "EARLY"
                                ? "bg-blue-500/10 text-blue-500"
                                : item.arrivalStatus === "LATE"
                                ? "bg-amber-500/10 text-amber-500"
                                : "bg-emerald-500/10 text-emerald-500"
                            }`}
                          >
                            {item.arrivalStatus}
                          </span>
                        </td>
                        <td className="py-3.5 px-4">
                          <span
                            className={`px-2.5 py-0.5 rounded-full text-xs font-bold ${
                              item.attendanceStatus === "COMPLETED"
                                ? "bg-emerald-500/10 text-emerald-500"
                                : "bg-amber-500/10 text-amber-500 animate-pulse"
                            }`}
                          >
                            {item.attendanceStatus}
                          </span>
                        </td>
                        <td className="py-3.5 px-4 text-right">
                          <Link
                            href={`/admin/employees/${item.employeeId}`}
                            className="p-1.5 text-slate-400 hover:text-amber-600 transition inline-block"
                            title="View Employee Profile"
                          >
                            <Eye className="w-4 h-4" />
                          </Link>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </main>
      </div>
    </div>
  );
}
