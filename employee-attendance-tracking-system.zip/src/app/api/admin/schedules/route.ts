import { getSession } from "@/lib/auth";
import { db } from "@/db";
import { schedules, auditLogs } from "@/db/schema";
import { eq } from "drizzle-orm";
import { NextResponse } from "next/server";

export async function GET() {
  const session = await getSession();
  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const schedList = await db.select().from(schedules).where(eq(schedules.isDefault, true));
  if (schedList.length === 0) {
    // Create default schedule if none
    const [newSched] = await db
      .insert(schedules)
      .values({
        companyName: "AJZ Consultants",
        timezone: "Asia/Karachi",
        startTime: "09:00",
        endTime: "18:00",
        gracePeriodMinutes: 15,
        lunchBreakStart: "13:00",
        lunchBreakEnd: "14:00",
        workingDays: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"],
        breakTrackingEnabled: true,
        isDefault: true,
      })
      .returning();
    return NextResponse.json({ schedule: newSched });
  }

  return NextResponse.json({ schedule: schedList[0] });
}

export async function PUT(req: Request) {
  const session = await getSession();
  if (!session || session.role !== "ADMIN") {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const body = await req.json();
    const {
      companyName,
      timezone,
      startTime,
      endTime,
      gracePeriodMinutes,
      lunchBreakStart,
      lunchBreakEnd,
      workingDays,
      breakTrackingEnabled,
    } = body;

    const schedList = await db.select().from(schedules).where(eq(schedules.isDefault, true));
    let schedId = schedList[0]?.id;

    if (!schedId) {
      const [newSched] = await db
        .insert(schedules)
        .values({
          companyName: companyName || "AJZ Consultants",
          timezone: timezone || "Asia/Karachi",
          startTime: startTime || "09:00",
          endTime: endTime || "18:00",
          gracePeriodMinutes: gracePeriodMinutes ?? 15,
          lunchBreakStart: lunchBreakStart || "13:00",
          lunchBreakEnd: lunchBreakEnd || "14:00",
          workingDays: workingDays || ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"],
          breakTrackingEnabled: breakTrackingEnabled ?? true,
          isDefault: true,
        })
        .returning();
      schedId = newSched.id;
    } else {
      await db
        .update(schedules)
        .set({
          companyName,
          timezone,
          startTime,
          endTime,
          gracePeriodMinutes: parseInt(String(gracePeriodMinutes), 10),
          lunchBreakStart,
          lunchBreakEnd,
          workingDays,
          breakTrackingEnabled,
          updatedAt: new Date(),
        })
        .where(eq(schedules.id, schedId));
    }

    await db.insert(auditLogs).values({
      adminId: session.userId,
      adminName: session.fullName || "Admin",
      action: "SCHEDULE_UPDATED",
      target: "Company Working Schedule",
      details: `Schedule updated: ${startTime} - ${endTime}, Grace: ${gracePeriodMinutes}m, Working Days: ${workingDays.join(", ")}`,
    });

    const updatedSched = await db.select().from(schedules).where(eq(schedules.id, schedId));

    return NextResponse.json({ success: true, schedule: updatedSched[0] });
  } catch (err: unknown) {
    console.error("Update schedule error:", err);
    return NextResponse.json(
      { error: "Failed to update schedule" },
      { status: 500 }
    );
  }
}
