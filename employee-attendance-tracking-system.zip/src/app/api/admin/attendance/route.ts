import { getSession } from "@/lib/auth";
import { db } from "@/db";
import { attendance, employees, schedules, auditLogs } from "@/db/schema";
import {
  calculateArrivalStatus,
  format12Hour,
} from "@/lib/time";
import { eq, desc, and, gte, lte } from "drizzle-orm";
import { NextResponse } from "next/server";

export async function GET(req: Request) {
  const session = await getSession();
  if (!session || session.role !== "ADMIN") {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { searchParams } = new URL(req.url);
  const date = searchParams.get("date");
  const startDate = searchParams.get("startDate");
  const endDate = searchParams.get("endDate");
  const employeeId = searchParams.get("employeeId");
  const departmentName = searchParams.get("department");
  const attendanceStatus = searchParams.get("attendanceStatus");
  const arrivalStatus = searchParams.get("arrivalStatus");

  const conditions = [];

  if (date) {
    conditions.push(eq(attendance.date, date));
  } else {
    if (startDate) conditions.push(gte(attendance.date, startDate));
    if (endDate) conditions.push(lte(attendance.date, endDate));
  }

  if (employeeId && employeeId !== "ALL") {
    conditions.push(eq(attendance.employeeId, employeeId));
  }

  if (attendanceStatus && attendanceStatus !== "ALL") {
    conditions.push(eq(attendance.attendanceStatus, attendanceStatus as any));
  }

  if (arrivalStatus && arrivalStatus !== "ALL") {
    conditions.push(eq(attendance.arrivalStatus, arrivalStatus as any));
  }

  const records = await db
    .select()
    .from(attendance)
    .where(conditions.length > 0 ? and(...conditions) : undefined)
    .orderBy(desc(attendance.date), desc(attendance.clockIn));

  // Get employee details
  const empList = await db.select().from(employees);
  const empMap = new Map(empList.map((e) => [e.id, e]));

  let filteredResult = records.map((r) => {
    const emp = empMap.get(r.employeeId);
    return {
      ...r,
      employeeName: emp ? emp.fullName : "Unknown",
      officialEmail: emp ? emp.officialEmail : "",
      employeeCode: emp ? emp.employeeCode : "",
      departmentName: emp ? emp.departmentName : "General",
      designation: emp ? emp.designation : "",
    };
  });

  if (departmentName && departmentName !== "ALL") {
    filteredResult = filteredResult.filter((r) => r.departmentName === departmentName);
  }

  return NextResponse.json({ records: filteredResult });
}

export async function POST(req: Request) {
  const session = await getSession();
  if (!session || session.role !== "ADMIN") {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const body = await req.json();
    const {
      employeeId,
      date,
      clockInTime, // e.g. "08:52"
      clockOutTime, // e.g. "17:58"
      breakMinutes = 60,
      notes = "Manual attendance entry by Admin",
    } = body;

    if (!employeeId || !date || !clockInTime) {
      return NextResponse.json(
        { error: "Employee, Date, and Clock In time are required" },
        { status: 400 }
      );
    }

    const empList = await db.select().from(employees).where(eq(employees.id, employeeId));
    if (empList.length === 0) {
      return NextResponse.json({ error: "Employee not found" }, { status: 404 });
    }
    const emp = empList[0];

    // Get schedule
    const sched = await db.select().from(schedules).where(eq(schedules.isDefault, true));
    const startTime = sched[0]?.startTime || "09:00";
    const endTime = sched[0]?.endTime || "18:00";
    const graceMinutes = sched[0]?.gracePeriodMinutes ?? 15;

    const clockInDate = new Date(`${date}T${clockInTime}:00+05:00`);
    const clockOutDate = clockOutTime ? new Date(`${date}T${clockOutTime}:00+05:00`) : null;

    const { arrivalStatus, arrivalMinutes, label } = calculateArrivalStatus(
      clockInDate,
      date,
      startTime,
      graceMinutes
    );

    let totalWorkSec = 0;
    let actualWorkSec = 0;
    const breakSec = (parseInt(String(breakMinutes), 10) || 0) * 60;
    let attendanceStatus: "WORKING" | "COMPLETED" = "WORKING";

    if (clockOutDate) {
      totalWorkSec = Math.floor((clockOutDate.getTime() - clockInDate.getTime()) / 1000);
      actualWorkSec = Math.max(0, totalWorkSec - breakSec);
      attendanceStatus = "COMPLETED";
    }

    const [newAtt] = await db
      .insert(attendance)
      .values({
        employeeId,
        date,
        scheduledStart: format12Hour(startTime),
        scheduledEnd: format12Hour(endTime),
        clockIn: clockInDate,
        clockOut: clockOutDate,
        totalWorkSeconds: totalWorkSec,
        breakSeconds: breakSec,
        actualWorkSeconds: actualWorkSec,
        arrivalStatus,
        arrivalMinutes,
        attendanceStatus,
        notes,
        isManualEntry: true,
        editedBy: session.userId,
      })
      .returning();

    await db.insert(auditLogs).values({
      adminId: session.userId,
      adminName: session.fullName || "Admin",
      action: "MANUAL_ATTENDANCE_ADDED",
      target: `${emp.fullName} (${date})`,
      details: `Added manual entry: In=${clockInTime}, Out=${clockOutTime || "N/A"}, Reason=${notes}`,
    });

    return NextResponse.json({ success: true, attendance: newAtt });
  } catch (err: unknown) {
    console.error("Manual attendance error:", err);
    return NextResponse.json(
      { error: "Failed to add manual attendance" },
      { status: 500 }
    );
  }
}
