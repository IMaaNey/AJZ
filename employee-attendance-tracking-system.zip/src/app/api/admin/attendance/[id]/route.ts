import { getSession } from "@/lib/auth";
import { db } from "@/db";
import { attendance, employees, schedules, auditLogs } from "@/db/schema";
import { calculateArrivalStatus, format12Hour } from "@/lib/time";
import { eq } from "drizzle-orm";
import { NextResponse } from "next/server";

export async function PUT(
  req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const session = await getSession();
  if (!session || session.role !== "ADMIN") {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { id } = await params;
  const body = await req.json();
  const { clockInTime, clockOutTime, breakMinutes, reason, attendanceStatus } = body;

  const attList = await db.select().from(attendance).where(eq(attendance.id, id));
  if (attList.length === 0) {
    return NextResponse.json({ error: "Attendance record not found" }, { status: 404 });
  }

  const oldAtt = attList[0];

  const empList = await db.select().from(employees).where(eq(employees.id, oldAtt.employeeId));
  const emp = empList[0];

  const sched = await db.select().from(schedules).where(eq(schedules.isDefault, true));
  const startTime = sched[0]?.startTime || "09:00";
  const graceMinutes = sched[0]?.gracePeriodMinutes ?? 15;

  let newClockIn = oldAtt.clockIn;
  let newClockOut = oldAtt.clockOut;

  if (clockInTime) {
    newClockIn = new Date(`${oldAtt.date}T${clockInTime}:00+05:00`);
  }

  if (clockOutTime) {
    newClockOut = new Date(`${oldAtt.date}T${clockOutTime}:00+05:00`);
  }

  const { arrivalStatus, arrivalMinutes } = calculateArrivalStatus(
    newClockIn,
    oldAtt.date,
    startTime,
    graceMinutes
  );

  let breakSec = oldAtt.breakSeconds;
  if (breakMinutes !== undefined) {
    breakSec = (parseInt(String(breakMinutes), 10) || 0) * 60;
  }

  let totalWorkSec = 0;
  let actualWorkSec = 0;
  let finalStatus = attendanceStatus || oldAtt.attendanceStatus;

  if (newClockOut) {
    totalWorkSec = Math.floor((newClockOut.getTime() - newClockIn.getTime()) / 1000);
    actualWorkSec = Math.max(0, totalWorkSec - breakSec);
    if (!attendanceStatus) finalStatus = "COMPLETED";
  }

  const [updatedAtt] = await db
    .update(attendance)
    .set({
      clockIn: newClockIn,
      clockOut: newClockOut,
      totalWorkSeconds: totalWorkSec,
      breakSeconds: breakSec,
      actualWorkSeconds: actualWorkSec,
      arrivalStatus,
      arrivalMinutes,
      attendanceStatus: finalStatus,
      notes: reason ? `Admin Edit: ${reason}` : oldAtt.notes,
      isManualEntry: true,
      editedBy: session.userId,
      updatedAt: new Date(),
    })
    .where(eq(attendance.id, id))
    .returning();

  await db.insert(auditLogs).values({
    adminId: session.userId,
    adminName: session.fullName || "Admin",
    action: "ATTENDANCE_EDITED",
    target: `${emp ? emp.fullName : "Employee"} (${oldAtt.date})`,
    details: `Updated attendance record. Reason: ${reason || "No reason provided"}`,
  });

  return NextResponse.json({ success: true, attendance: updatedAtt });
}
