import { getSession } from "@/lib/auth";
import { db } from "@/db";
import { holidays, auditLogs } from "@/db/schema";
import { eq } from "drizzle-orm";
import { NextResponse } from "next/server";

export async function DELETE(
  req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const session = await getSession();
  if (!session || session.role !== "ADMIN") {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { id } = await params;

  const h = await db.select().from(holidays).where(eq(holidays.id, id));
  if (h.length === 0) {
    return NextResponse.json({ error: "Holiday not found" }, { status: 404 });
  }

  const holiday = h[0];

  await db.delete(holidays).where(eq(holidays.id, id));

  await db.insert(auditLogs).values({
    adminId: session.userId,
    adminName: session.fullName || "Admin",
    action: "HOLIDAY_DELETED",
    target: `${holiday.name} (${holiday.date})`,
    details: "Holiday removed from company schedule.",
  });

  return NextResponse.json({ success: true, message: "Holiday deleted successfully" });
}
