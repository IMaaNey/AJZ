import { getSession } from "@/lib/auth";
import { db } from "@/db";
import { holidays, auditLogs } from "@/db/schema";
import { desc, eq } from "drizzle-orm";
import { NextResponse } from "next/server";

export async function GET() {
  const session = await getSession();
  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const list = await db.select().from(holidays).orderBy(desc(holidays.date));
  return NextResponse.json({ holidays: list });
}

export async function POST(req: Request) {
  const session = await getSession();
  if (!session || session.role !== "ADMIN") {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const { name, date, description } = await req.json();

    if (!name || !date) {
      return NextResponse.json(
        { error: "Holiday name and date are required" },
        { status: 400 }
      );
    }

    const [newHoliday] = await db
      .insert(holidays)
      .values({
        name: String(name).trim(),
        date: String(date).trim(),
        description: description || "",
      })
      .returning();

    await db.insert(auditLogs).values({
      adminId: session.userId,
      adminName: session.fullName || "Admin",
      action: "HOLIDAY_ADDED",
      target: `${name} (${date})`,
      details: description || "Company holiday added.",
    });

    return NextResponse.json({ success: true, holiday: newHoliday });
  } catch (err: unknown) {
    console.error("Create holiday error:", err);
    return NextResponse.json(
      { error: "Failed to add holiday" },
      { status: 500 }
    );
  }
}
