import { getSession } from "@/lib/auth";
import { db } from "@/db";
import { employees, users, attendance, auditLogs } from "@/db/schema";
import { getKarachiDateString, formatDuration } from "@/lib/time";
import { eq, desc, and, gte, lte } from "drizzle-orm";
import { NextResponse } from "next/server";

export async function GET(
  req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const session = await getSession();
  if (!session || session.role !== "ADMIN") {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { id } = await params;

  const empList = await db.select().from(employees).where(eq(employees.id, id));
  if (empList.length === 0) {
    return NextResponse.json({ error: "Employee not found" }, { status: 404 });
  }

  const employee = empList[0];

  // Fetch associated user
  const userList = await db.select().from(users).where(eq(users.id, employee.userId));
  const user = userList[0] || null;

  // Fetch monthly summary for current month
  const todayStr = getKarachiDateString();
  const [year, month] = todayStr.split("-");
  const monthStart = `${year}-${month}-01`;
  const lastDay = new Date(parseInt(year, 10), parseInt(month, 10), 0).getDate();
  const pad = (n: number) => String(n).padStart(2, "0");
  const monthEnd = `${year}-${month}-${pad(lastDay)}`;

  const attRecords = await db
    .select()
    .from(attendance)
    .where(
      and(
        eq(attendance.employeeId, id),
        gte(attendance.date, monthStart),
        lte(attendance.date, monthEnd)
      )
    )
    .orderBy(desc(attendance.date));

  let presentCount = 0;
  let lateCount = 0;
  let earlyCount = 0;
  let onTimeCount = 0;
  let totalWorkSec = 0;

  for (const r of attRecords) {
    if (r.attendanceStatus === "COMPLETED" || r.attendanceStatus === "WORKING") {
      presentCount++;
      totalWorkSec += r.actualWorkSeconds;
      if (r.arrivalStatus === "LATE") lateCount++;
      else if (r.arrivalStatus === "EARLY") earlyCount++;
      else onTimeCount++;
    }
  }

  return NextResponse.json({
    employee,
    user: user ? { id: user.id, email: user.email, role: user.role, status: user.status } : null,
    summary: {
      present: presentCount,
      late: lateCount,
      early: earlyCount,
      onTime: onTimeCount,
      totalHoursFormatted: formatDuration(totalWorkSec),
    },
    attendanceHistory: attRecords,
  });
}

export async function PUT(
  req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const session = await getSession();
  if (!session || session.role !== "ADMIN") {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { id } = await params;
  const body = await req.json();
  const { fullName, departmentName, designation, status, phone } = body;

  const empList = await db.select().from(employees).where(eq(employees.id, id));
  if (empList.length === 0) {
    return NextResponse.json({ error: "Employee not found" }, { status: 404 });
  }

  const oldEmp = empList[0];

  const [updatedEmp] = await db
    .update(employees)
    .set({
      fullName: fullName ?? oldEmp.fullName,
      departmentName: departmentName ?? oldEmp.departmentName,
      designation: designation ?? oldEmp.designation,
      status: status ?? oldEmp.status,
      phone: phone ?? oldEmp.phone,
      updatedAt: new Date(),
    })
    .where(eq(employees.id, id))
    .returning();

  // Also update user status if updated
  if (status && status !== oldEmp.status) {
    await db
      .update(users)
      .set({ status, updatedAt: new Date() })
      .where(eq(users.id, oldEmp.userId));
  }

  // Audit Log
  await db.insert(auditLogs).values({
    adminId: session.userId,
    adminName: session.fullName || "Admin",
    action: status !== oldEmp.status ? (status === "INACTIVE" ? "EMPLOYEE_DEACTIVATED" : "EMPLOYEE_REACTIVATED") : "EMPLOYEE_UPDATED",
    target: `${updatedEmp.fullName} (${updatedEmp.officialEmail})`,
    details: `Updated details: Dept=${updatedEmp.departmentName}, Designation=${updatedEmp.designation}, Status=${updatedEmp.status}`,
  });

  return NextResponse.json({ success: true, employee: updatedEmp });
}
