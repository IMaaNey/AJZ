import { getSession, hashPassword } from "@/lib/auth";
import { db } from "@/db";
import { employees, users, auditLogs } from "@/db/schema";
import { eq } from "drizzle-orm";
import { NextResponse } from "next/server";

export async function POST(
  req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const session = await getSession();
  if (!session || session.role !== "ADMIN") {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { id } = await params;
  const { newPassword } = await req.json();

  if (!newPassword || String(newPassword).length < 6) {
    return NextResponse.json(
      { error: "New password must be at least 6 characters" },
      { status: 400 }
    );
  }

  const empList = await db.select().from(employees).where(eq(employees.id, id));
  if (empList.length === 0) {
    return NextResponse.json({ error: "Employee not found" }, { status: 404 });
  }

  const emp = empList[0];
  const newHash = await hashPassword(newPassword);

  await db
    .update(users)
    .set({ passwordHash: newHash, updatedAt: new Date() })
    .where(eq(users.id, emp.userId));

  await db.insert(auditLogs).values({
    adminId: session.userId,
    adminName: session.fullName || "Admin",
    action: "PASSWORD_RESET",
    target: `${emp.fullName} (${emp.officialEmail})`,
    details: `Password reset by Admin.`,
  });

  return NextResponse.json({ success: true, message: "Password updated successfully" });
}
