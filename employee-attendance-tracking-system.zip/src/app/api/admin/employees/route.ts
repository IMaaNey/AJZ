import { getSession } from "@/lib/auth";
import { db } from "@/db";
import { employees, users, departments, schedules, attendance, auditLogs } from "@/db/schema";
import { hashPassword } from "@/lib/auth";
import { getKarachiDateString } from "@/lib/time";
import { eq, desc, and, ilike, or } from "drizzle-orm";
import { NextResponse } from "next/server";

export async function GET(req: Request) {
  const session = await getSession();
  if (!session || session.role !== "ADMIN") {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { searchParams } = new URL(req.url);
  const search = searchParams.get("search")?.trim() || "";
  const deptFilter = searchParams.get("department");
  const statusFilter = searchParams.get("status");

  const todayStr = getKarachiDateString();

  // Fetch employees
  const conditions = [];

  if (search) {
    conditions.push(
      or(
        ilike(employees.fullName, `%${search}%`),
        ilike(employees.officialEmail, `%${search}%`),
        ilike(employees.employeeCode, `%${search}%`),
        ilike(employees.designation, `%${search}%`)
      )
    );
  }

  if (deptFilter && deptFilter !== "ALL") {
    conditions.push(eq(employees.departmentName, deptFilter));
  }

  if (statusFilter && statusFilter !== "ALL") {
    conditions.push(eq(employees.status, statusFilter as any));
  }

  const empList = await db
    .select()
    .from(employees)
    .where(conditions.length > 0 ? and(...conditions) : undefined)
    .orderBy(desc(employees.createdAt));

  // Fetch today's attendance records to append today's status
  const todayAtt = await db
    .select()
    .from(attendance)
    .where(eq(attendance.date, todayStr));

  const attMap = new Map(todayAtt.map((a) => [a.employeeId, a]));

  const result = empList.map((e) => {
    const att = attMap.get(e.id);
    return {
      ...e,
      todayStatus: att
        ? att.attendanceStatus
        : e.status === "INACTIVE"
        ? "INACTIVE"
        : "NOT_CLOCKED_IN",
      todayClockIn: att ? att.clockIn : null,
      todayClockOut: att ? att.clockOut : null,
      todayArrivalStatus: att ? att.arrivalStatus : null,
    };
  });

  return NextResponse.json({ employees: result });
}

export async function POST(req: Request) {
  const session = await getSession();
  if (!session || session.role !== "ADMIN") {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const body = await req.json();
    const {
      fullName,
      officialEmail,
      password,
      departmentName = "Engineering",
      designation = "Software Engineer",
      joiningDate = getKarachiDateString(),
      role = "EMPLOYEE",
      status = "ACTIVE",
      phone = "",
    } = body;

    if (!fullName || !officialEmail || !password) {
      return NextResponse.json(
        { error: "Full name, official email, and password are required" },
        { status: 400 }
      );
    }

    const cleanEmail = String(officialEmail).trim().toLowerCase();

    // Check duplicate
    const existingUser = await db.select().from(users).where(eq(users.email, cleanEmail));
    if (existingUser.length > 0) {
      return NextResponse.json(
        { error: "An account with this official email already exists" },
        { status: 400 }
      );
    }

    // Get default schedule
    const defaultSched = await db.select().from(schedules).where(eq(schedules.isDefault, true));
    const scheduleId = defaultSched[0]?.id;

    // Get or create department ID
    let deptId: string | null = null;
    const deptList = await db
      .select()
      .from(departments)
      .where(eq(departments.name, departmentName));

    if (deptList.length > 0) {
      deptId = deptList[0].id;
    } else {
      const [newDept] = await db
        .insert(departments)
        .values({ name: departmentName, description: `${departmentName} Department` })
        .returning();
      deptId = newDept.id;
    }

    const passwordHash = await hashPassword(password);

    // Create User
    const [newUser] = await db
      .insert(users)
      .values({
        email: cleanEmail,
        passwordHash,
        role,
        status,
      })
      .returning();

    // Generate unique employee code (e.g. AJZ-105)
    const empCountResult = await db.select().from(employees);
    const empCode = `AJZ-${String(empCountResult.length + 101).padStart(3, "0")}`;

    // Create Employee Profile
    const [newEmp] = await db
      .insert(employees)
      .values({
        userId: newUser.id,
        employeeCode: empCode,
        fullName: String(fullName).trim(),
        officialEmail: cleanEmail,
        departmentId: deptId,
        departmentName,
        designation,
        joiningDate,
        phone,
        scheduleId,
        status,
      })
      .returning();

    // Log Audit
    await db.insert(auditLogs).values({
      adminId: session.userId,
      adminName: session.fullName || "Admin",
      action: "EMPLOYEE_CREATED",
      target: `${newEmp.fullName} (${cleanEmail})`,
      details: `Created account with code ${empCode}, department ${departmentName}, designation ${designation}, role ${role}.`,
    });

    return NextResponse.json({ success: true, employee: newEmp });
  } catch (err: unknown) {
    console.error("Create employee error:", err);
    return NextResponse.json(
      { error: "Failed to create employee" },
      { status: 500 }
    );
  }
}
