import { getSession } from "@/lib/auth";
import { db } from "@/db";
import { attendance, employees, holidays, schedules, leaveRequests } from "@/db/schema";
import { getKarachiDateString, formatDuration } from "@/lib/time";
import { eq, and } from "drizzle-orm";
import { NextResponse } from "next/server";

export async function GET() {
  const session = await getSession();
  if (!session || session.role !== "ADMIN") {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const todayStr = getKarachiDateString();

  // 1. Total Active Employees
  const activeEmps = await db
    .select()
    .from(employees)
    .where(eq(employees.status, "ACTIVE"));

  const totalEmployees = activeEmps.length;

  // 2. Schedule
  const sched = await db.select().from(schedules).where(eq(schedules.isDefault, true));
  const workingDays: string[] = (sched[0]?.workingDays as string[]) || [
    "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"
  ];

  // 3. Today's Attendance Records
  const todayAtt = await db
    .select()
    .from(attendance)
    .where(eq(attendance.date, todayStr));

  // Check Holiday / Leave
  const holidayList = await db.select().from(holidays).where(eq(holidays.date, todayStr));
  const isHolidayToday = holidayList.length > 0;

  let presentCount = 0;
  let currentlyWorkingCount = 0;
  let lateCount = 0;
  let totalWorkSecSum = 0;

  const attendedEmpIds = new Set<string>();

  for (const record of todayAtt) {
    attendedEmpIds.add(record.employeeId);

    if (record.attendanceStatus === "WORKING" || record.attendanceStatus === "COMPLETED") {
      presentCount++;
      totalWorkSecSum += record.actualWorkSeconds;
    }

    if (record.attendanceStatus === "WORKING") {
      currentlyWorkingCount++;
    }

    if (record.arrivalStatus === "LATE") {
      lateCount++;
    }
  }

  // Calculate Absent Today
  let absentCount = 0;
  if (!isHolidayToday) {
    const todayDateObj = new Date(`${todayStr}T00:00:00+05:00`);
    const dayName = new Intl.DateTimeFormat("en-US", { weekday: "long" }).format(todayDateObj);

    if (workingDays.includes(dayName)) {
      // Find employees on approved leave today
      const approvedLeaves = await db
        .select()
        .from(leaveRequests)
        .where(eq(leaveRequests.status, "APPROVED"));

      const onLeaveEmpIds = new Set(
        approvedLeaves
          .filter((l) => l.startDate <= todayStr && l.endDate >= todayStr)
          .map((l) => l.employeeId)
      );

      for (const emp of activeEmps) {
        if (!attendedEmpIds.has(emp.id) && !onLeaveEmpIds.has(emp.id)) {
          absentCount++;
        }
      }
    }
  }

  const avgWorkSeconds = presentCount > 0 ? Math.floor(totalWorkSecSum / presentCount) : 0;

  // Build Detailed Today Table
  const empMap = new Map(activeEmps.map((e) => [e.id, e]));

  const todayList = todayAtt.map((att) => {
    const emp = empMap.get(att.employeeId);
    return {
      id: att.id,
      employeeId: att.employeeId,
      employeeName: emp ? emp.fullName : "Unknown Employee",
      officialEmail: emp ? emp.officialEmail : "",
      department: emp ? emp.departmentName : "General",
      designation: emp ? emp.designation : "",
      clockIn: att.clockIn,
      clockOut: att.clockOut,
      workingHoursFormatted: formatDuration(att.actualWorkSeconds),
      arrivalStatus: att.arrivalStatus,
      arrivalMinutes: att.arrivalMinutes,
      attendanceStatus: att.attendanceStatus,
    };
  });

  return NextResponse.json({
    stats: {
      totalEmployees,
      presentToday: presentCount,
      currentlyWorking: currentlyWorkingCount,
      lateToday: lateCount,
      absentToday: absentCount,
      averageWorkingHoursFormatted: formatDuration(avgWorkSeconds),
      averageWorkSeconds: avgWorkSeconds,
    },
    todayAttendance: todayList,
    date: todayStr,
  });
}
