import { getSession } from "@/lib/auth";
import { db } from "@/db";
import { leaveRequests, employees, auditLogs } from "@/db/schema";
import { desc, eq, and } from "drizzle-orm";
import { NextResponse } from "next/server";

export async function GET() {
  const session = await getSession();
  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  let requests;

  if (session.role === "ADMIN") {
    requests = await db
      .select()
      .from(leaveRequests)
      .orderBy(desc(leaveRequests.createdAt));
  } else {
    if (!session.employeeId) {
      return NextResponse.json({ error: "Employee profile required" }, { status: 400 });
    }
    requests = await db
      .select()
      .from(leaveRequests)
      .where(eq(leaveRequests.employeeId, session.employeeId))
      .orderBy(desc(leaveRequests.createdAt));
  }

  // Get employee details
  const empList = await db.select().from(employees);
  const empMap = new Map(empList.map((e) => [e.id, e]));

  const result = requests.map((r) => {
    const emp = empMap.get(r.employeeId);
    return {
      ...r,
      employeeName: emp ? emp.fullName : "Unknown",
      officialEmail: emp ? emp.officialEmail : "",
      departmentName: emp ? emp.departmentName : "General",
    };
  });

  return NextResponse.json({ leaves: result });
}

export async function POST(req: Request) {
  const session = await getSession();
  if (!session || !session.employeeId) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const { leaveType = "CASUAL", startDate, endDate, reason } = await req.json();

    if (!startDate || !endDate || !reason) {
      return NextResponse.json(
        { error: "Start date, end date, and reason are required" },
        { status: 400 }
      );
    }

    const [newLeave] = await db
      .insert(leaveRequests)
      .values({
        employeeId: session.employeeId,
        leaveType,
        startDate,
        endDate,
        reason,
        status: "PENDING",
      })
      .returning();

    return NextResponse.json({ success: true, leave: newLeave });
  } catch (err: unknown) {
    console.error("Create leave request error:", err);
    return NextResponse.json(
      { error: "Failed to submit leave request" },
      { status: 500 }
    );
  }
}
