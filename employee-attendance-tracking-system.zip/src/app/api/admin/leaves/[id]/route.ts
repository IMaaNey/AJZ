import { getSession } from "@/lib/auth";
import { db } from "@/db";
import { leaveRequests, employees, auditLogs } from "@/db/schema";
import { eq } from "drizzle-orm";
import { NextResponse } from "next/server";

export async function PUT(
  req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const session = await getSession();
  if (!session || session.role !== "ADMIN") {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { id } = await params;
  const { status, reviewReason } = await req.json();

  if (!status || !["APPROVED", "REJECTED"].includes(status)) {
    return NextResponse.json({ error: "Invalid status" }, { status: 400 });
  }

  const leaveList = await db.select().from(leaveRequests).where(eq(leaveRequests.id, id));
  if (leaveList.length === 0) {
    return NextResponse.json({ error: "Leave request not found" }, { status: 404 });
  }

  const leave = leaveList[0];
  const empList = await db.select().from(employees).where(eq(employees.id, leave.employeeId));
  const emp = empList[0];

  const [updatedLeave] = await db
    .update(leaveRequests)
    .set({
      status,
      reviewReason: reviewReason || "",
      reviewedBy: session.userId,
      updatedAt: new Date(),
    })
    .where(eq(leaveRequests.id, id))
    .returning();

  await db.insert(auditLogs).values({
    adminId: session.userId,
    adminName: session.fullName || "Admin",
    action: status === "APPROVED" ? "LEAVE_APPROVED" : "LEAVE_REJECTED",
    target: `${emp ? emp.fullName : "Employee"} (${leave.startDate} to ${leave.endDate})`,
    details: `Leave status set to ${status}. Note: ${reviewReason || "None"}`,
  });

  return NextResponse.json({ success: true, leave: updatedLeave });
}
