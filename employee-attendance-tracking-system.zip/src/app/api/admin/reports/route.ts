import { getSession } from "@/lib/auth";
import { db } from "@/db";
import { employees, attendance, holidays, schedules, leaveRequests } from "@/db/schema";
import { getKarachiDateString, formatDuration } from "@/lib/time";
import { eq, and, gte, lte } from "drizzle-orm";
import { NextResponse } from "next/server";

export async function GET(req: Request) {
  const session = await getSession();
  if (!session || session.role !== "ADMIN") {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { searchParams } = new URL(req.url);
  const todayStr = getKarachiDateString();
  const [year, month] = todayStr.split("-");

  const startDate = searchParams.get("startDate") || `${year}-${month}-01`;
  const endDate = searchParams.get("endDate") || todayStr;
  const deptFilter = searchParams.get("department");
  const empFilter = searchParams.get("employeeId");

  // Fetch active employees
  let empList = await db.select().from(employees).where(eq(employees.status, "ACTIVE"));

  if (deptFilter && deptFilter !== "ALL") {
    empList = empList.filter((e) => e.departmentName === deptFilter);
  }
  if (empFilter && empFilter !== "ALL") {
    empList = empList.filter((e) => e.id === empFilter);
  }

  // Fetch all attendance records in range
  const attRecords = await db
    .select()
    .from(attendance)
    .where(and(gte(attendance.date, startDate), lte(attendance.date, endDate)));

  // Fetch holidays in range
  const holidayList = await db
    .select()
    .from(holidays)
    .where(and(gte(holidays.date, startDate), lte(holidays.date, endDate)));
  const holidayDates = new Set(holidayList.map((h) => h.date));

  // Fetch approved leaves in range
  const approvedLeaves = await db
    .select()
    .from(leaveRequests)
    .where(eq(leaveRequests.status, "APPROVED"));

  // Default schedule working days
  const sched = await db.select().from(schedules).where(eq(schedules.isDefault, true));
  const workingDays: string[] = (sched[0]?.workingDays as string[]) || [
    "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"
  ];

  // Map attendance by employeeId -> date -> record
  const empAttMap = new Map<string, Map<string, typeof attRecords[0]>>();
  for (const r of attRecords) {
    if (!empAttMap.has(r.employeeId)) {
      empAttMap.set(r.employeeId, new Map());
    }
    empAttMap.get(r.employeeId)!.set(r.date, r);
  }

  // Calculate total schedule working days in date range
  const allDatesInRange: string[] = [];
  const curDate = new Date(`${startDate}T00:00:00+05:00`);
  const stopDate = new Date(`${endDate}T00:00:00+05:00`);

  while (curDate <= stopDate) {
    const pad = (n: number) => String(n).padStart(2, "0");
    const dStr = `${curDate.getFullYear()}-${pad(curDate.getMonth() + 1)}-${pad(curDate.getDate())}`;
    const dayName = new Intl.DateTimeFormat("en-US", { weekday: "long" }).format(curDate);

    if (workingDays.includes(dayName) && !holidayDates.has(dStr)) {
      allDatesInRange.push(dStr);
    }
    curDate.setDate(curDate.getDate() + 1);
  }

  const reportData = empList.map((emp) => {
    const attMap = empAttMap.get(emp.id) || new Map();

    let present = 0;
    let absent = 0;
    let late = 0;
    let early = 0;
    let onTime = 0;
    let totalWorkSec = 0;

    for (const dStr of allDatesInRange) {
      // Check if employee was on approved leave on date
      const onLeave = approvedLeaves.some(
        (l) => l.employeeId === emp.id && l.startDate <= dStr && l.endDate >= dStr
      );

      if (onLeave) continue;

      const record = attMap.get(dStr);
      if (record && (record.attendanceStatus === "COMPLETED" || record.attendanceStatus === "WORKING")) {
        present++;
        totalWorkSec += record.actualWorkSeconds;
        if (record.arrivalStatus === "LATE") late++;
        else if (record.arrivalStatus === "EARLY") early++;
        else onTime++;
      } else {
        absent++;
      }
    }

    const avgWorkSec = present > 0 ? Math.floor(totalWorkSec / present) : 0;

    return {
      employeeId: emp.id,
      fullName: emp.fullName,
      officialEmail: emp.officialEmail,
      employeeCode: emp.employeeCode,
      departmentName: emp.departmentName,
      designation: emp.designation,
      workingDaysCount: allDatesInRange.length,
      presentCount: present,
      absentCount: absent,
      lateCount: late,
      earlyCount: early,
      onTimeCount: onTime,
      totalHoursFormatted: formatDuration(totalWorkSec),
      totalWorkSeconds: totalWorkSec,
      avgHoursFormatted: formatDuration(avgWorkSec),
      avgWorkSeconds: avgWorkSec,
    };
  });

  return NextResponse.json({
    startDate,
    endDate,
    workingDaysCount: allDatesInRange.length,
    reports: reportData,
  });
}
