import { getSession } from "@/lib/auth";
import { db } from "@/db";
import { attendance, attendanceBreaks, employees, schedules, holidays, leaveRequests } from "@/db/schema";
import { getKarachiDateString, format12Hour } from "@/lib/time";
import { eq, and } from "drizzle-orm";
import { NextResponse } from "next/server";

export async function GET() {
  const session = await getSession();
  if (!session || !session.employeeId) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const dateStr = getKarachiDateString();

  // 1. Get Employee & Schedule
  const empList = await db.select().from(employees).where(eq(employees.id, session.employeeId));
  if (empList.length === 0) {
    return NextResponse.json({ error: "Employee profile not found" }, { status: 404 });
  }
  const employee = empList[0];

  let schedule = null;
  if (employee.scheduleId) {
    const s = await db.select().from(schedules).where(eq(schedules.id, employee.scheduleId));
    if (s.length > 0) schedule = s[0];
  }
  if (!schedule) {
    const s = await db.select().from(schedules).where(eq(schedules.isDefault, true));
    if (s.length > 0) schedule = s[0];
  }

  const scheduledStartFormatted = format12Hour(schedule?.startTime || "09:00");
  const scheduledEndFormatted = format12Hour(schedule?.endTime || "18:00");

  // Check if today is a Holiday
  const holidayList = await db.select().from(holidays).where(eq(holidays.date, dateStr));
  const isHoliday = holidayList.length > 0 ? holidayList[0] : null;

  // Check if today is approved Leave
  const leaveList = await db
    .select()
    .from(leaveRequests)
    .where(
      and(
        eq(leaveRequests.employeeId, employee.id),
        eq(leaveRequests.status, "APPROVED")
      )
    );
  const isLeave = leaveList.find((l) => l.startDate <= dateStr && l.endDate >= dateStr) || null;

  // 2. Get Today's Attendance Record for Employee
  const attList = await db
    .select()
    .from(attendance)
    .where(
      and(
        eq(attendance.employeeId, session.employeeId),
        eq(attendance.date, dateStr)
      )
    );

  const todayAtt = attList.length > 0 ? attList[0] : null;

  let activeBreak = null;
  let totalBreakSeconds = 0;
  let currentElapsedSeconds = 0;

  if (todayAtt) {
    // Get all breaks for today's session
    const breaks = await db
      .select()
      .from(attendanceBreaks)
      .where(eq(attendanceBreaks.attendanceId, todayAtt.id));

    const now = new Date();

    for (const b of breaks) {
      if (b.endTime) {
        totalBreakSeconds += b.durationSeconds;
      } else {
        // Ongoing break
        activeBreak = b;
        const currentBreakSec = Math.floor((now.getTime() - new Date(b.startTime).getTime()) / 1000);
        totalBreakSeconds += currentBreakSec;
      }
    }

    if (todayAtt.attendanceStatus === "WORKING") {
      const clockInMs = new Date(todayAtt.clockIn).getTime();
      const elapsedTotalSec = Math.floor((now.getTime() - clockInMs) / 1000);
      currentElapsedSeconds = Math.max(0, elapsedTotalSec - totalBreakSeconds);
    } else {
      currentElapsedSeconds = todayAtt.actualWorkSeconds;
      totalBreakSeconds = todayAtt.breakSeconds;
    }
  }

  return NextResponse.json({
    date: dateStr,
    schedule: {
      startTime: schedule?.startTime || "09:00",
      endTime: schedule?.endTime || "18:00",
      scheduledStartFormatted,
      scheduledEndFormatted,
      gracePeriodMinutes: schedule?.gracePeriodMinutes || 15,
      lunchBreakStart: schedule?.lunchBreakStart || "13:00",
      lunchBreakEnd: schedule?.lunchBreakEnd || "14:00",
      breakTrackingEnabled: schedule?.breakTrackingEnabled ?? true,
    },
    isHoliday,
    isLeave,
    attendance: todayAtt,
    activeBreak,
    totalBreakSeconds,
    currentElapsedSeconds,
  });
}
