import { getSession } from "@/lib/auth";
import { db } from "@/db";
import { attendance, holidays, schedules } from "@/db/schema";
import { getKarachiDateString, formatDuration } from "@/lib/time";
import { eq, and, gte, lte } from "drizzle-orm";
import { NextResponse } from "next/server";

export async function GET(req: Request) {
  const session = await getSession();
  if (!session || !session.employeeId) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { searchParams } = new URL(req.url);
  const todayStr = getKarachiDateString();
  const [currentYear, currentMonthStr] = todayStr.split("-");

  const year = parseInt(searchParams.get("year") || currentYear, 10);
  const month = parseInt(searchParams.get("month") || currentMonthStr, 10);

  const pad = (n: number) => String(n).padStart(2, "0");
  const monthStart = `${year}-${pad(month)}-01`;
  const lastDay = new Date(year, month, 0).getDate();
  const monthEnd = `${year}-${pad(month)}-${pad(lastDay)}`;

  // Fetch employee attendance for month
  const records = await db
    .select()
    .from(attendance)
    .where(
      and(
        eq(attendance.employeeId, session.employeeId),
        gte(attendance.date, monthStart),
        lte(attendance.date, monthEnd)
      )
    );

  // Fetch holidays for month
  const holidayList = await db
    .select()
    .from(holidays)
    .where(and(gte(holidays.date, monthStart), lte(holidays.date, monthEnd)));

  const holidayDates = new Set(holidayList.map((h) => h.date));

  // Get active schedule
  const defaultSched = await db.select().from(schedules).where(eq(schedules.isDefault, true));
  const workingDays: string[] = (defaultSched[0]?.workingDays as string[]) || [
    "Monday",
    "Tuesday",
    "Wednesday",
    "Thursday",
    "Friday",
    "Saturday",
  ];

  // Calculate stats
  let totalWorkingDaysCount = 0;
  let presentCount = 0;
  let absentCount = 0;
  let lateCount = 0;
  let earlyCount = 0;
  let onTimeCount = 0;
  let totalWorkSeconds = 0;

  const recordsByDate = new Map<string, typeof records[0]>();
  for (const r of records) {
    recordsByDate.set(r.date, r);
  }

  // Iterate all days up to today or month end
  for (let d = 1; d <= lastDay; d++) {
    const dateStr = `${year}-${pad(month)}-${pad(d)}`;
    if (dateStr > todayStr) break; // Don't count future days as absent

    const dateObj = new Date(`${dateStr}T00:00:00+05:00`);
    const dayName = new Intl.DateTimeFormat("en-US", { weekday: "long" }).format(dateObj);

    const isWorkingDay = workingDays.includes(dayName);
    const isHoliday = holidayDates.has(dateStr);

    if (isWorkingDay && !isHoliday) {
      totalWorkingDaysCount++;

      const record = recordsByDate.get(dateStr);
      if (record) {
        if (
          record.attendanceStatus === "COMPLETED" ||
          record.attendanceStatus === "WORKING" ||
          record.attendanceStatus === "HALF_DAY"
        ) {
          presentCount++;
          totalWorkSeconds += record.actualWorkSeconds;

          if (record.arrivalStatus === "LATE") lateCount++;
          else if (record.arrivalStatus === "EARLY") earlyCount++;
          else onTimeCount++;
        } else if (record.attendanceStatus === "ABSENT") {
          absentCount++;
        }
      } else {
        // No record on a past working day = absent
        absentCount++;
      }
    }
  }

  const avgSeconds = presentCount > 0 ? Math.floor(totalWorkSeconds / presentCount) : 0;

  const monthNames = [
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"
  ];
  const monthName = `${monthNames[month - 1]} ${year}`;

  return NextResponse.json({
    monthName,
    year,
    month,
    stats: {
      workingDays: totalWorkingDaysCount,
      present: presentCount,
      absent: absentCount,
      late: lateCount,
      early: earlyCount,
      onTime: onTimeCount,
      totalHoursFormatted: formatDuration(totalWorkSeconds),
      totalWorkSeconds,
      avgHoursFormatted: formatDuration(avgSeconds),
      avgSeconds,
    },
    records,
  });
}
