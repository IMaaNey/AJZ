import { getSession } from "@/lib/auth";
import { db } from "@/db";
import { attendance, employees, schedules } from "@/db/schema";
import {
  getKarachiDateString,
  getKarachiNow,
  calculateArrivalStatus,
  format12Hour,
} from "@/lib/time";
import { eq, and } from "drizzle-orm";
import { NextResponse } from "next/server";

export async function POST() {
  const session = await getSession();
  if (!session || !session.employeeId) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const dateStr = getKarachiDateString();
  const serverNow = getKarachiNow();

  // 1. Check if already clocked in today
  const existingAtt = await db
    .select()
    .from(attendance)
    .where(
      and(
        eq(attendance.employeeId, session.employeeId),
        eq(attendance.date, dateStr)
      )
    );

  if (existingAtt.length > 0) {
    return NextResponse.json(
      { error: "You have already clocked in today." },
      { status: 400 }
    );
  }

  // 2. Get Employee and Schedule
  const empList = await db
    .select()
    .from(employees)
    .where(eq(employees.id, session.employeeId));

  if (empList.length === 0) {
    return NextResponse.json({ error: "Employee profile not found" }, { status: 404 });
  }

  const employee = empList[0];

  let schedule = null;
  if (employee.scheduleId) {
    const s = await db.select().from(schedules).where(eq(schedules.id, employee.scheduleId));
    if (s.length > 0) schedule = s[0];
  }
  if (!schedule) {
    const s = await db.select().from(schedules).where(eq(schedules.isDefault, true));
    if (s.length > 0) schedule = s[0];
  }

  const startTime = schedule?.startTime || "09:00";
  const endTime = schedule?.endTime || "18:00";
  const gracePeriod = schedule?.gracePeriodMinutes ?? 15;

  const { arrivalStatus, arrivalMinutes, label } = calculateArrivalStatus(
    serverNow,
    dateStr,
    startTime,
    gracePeriod
  );

  const [newAttendance] = await db
    .insert(attendance)
    .values({
      employeeId: session.employeeId,
      date: dateStr,
      scheduledStart: format12Hour(startTime),
      scheduledEnd: format12Hour(endTime),
      clockIn: serverNow,
      attendanceStatus: "WORKING",
      arrivalStatus,
      arrivalMinutes,
      totalWorkSeconds: 0,
      breakSeconds: 0,
      actualWorkSeconds: 0,
      notes: `Arrival: ${label}`,
    })
    .returning();

  return NextResponse.json({
    success: true,
    attendance: newAttendance,
    arrivalLabel: label,
  });
}
