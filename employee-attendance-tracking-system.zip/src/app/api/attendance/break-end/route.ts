import { getSession } from "@/lib/auth";
import { db } from "@/db";
import { attendance, attendanceBreaks } from "@/db/schema";
import { getKarachiDateString, getKarachiNow } from "@/lib/time";
import { eq, and, isNull } from "drizzle-orm";
import { NextResponse } from "next/server";

export async function POST() {
  const session = await getSession();
  if (!session || !session.employeeId) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const dateStr = getKarachiDateString();
  const serverNow = getKarachiNow();

  // Find active attendance
  const attList = await db
    .select()
    .from(attendance)
    .where(
      and(
        eq(attendance.employeeId, session.employeeId),
        eq(attendance.date, dateStr),
        eq(attendance.attendanceStatus, "WORKING")
      )
    );

  if (attList.length === 0) {
    return NextResponse.json({ error: "No active working session found." }, { status: 400 });
  }

  const activeAtt = attList[0];

  // Find open break
  const openBreaks = await db
    .select()
    .from(attendanceBreaks)
    .where(
      and(
        eq(attendanceBreaks.attendanceId, activeAtt.id),
        isNull(attendanceBreaks.endTime)
      )
    );

  if (openBreaks.length === 0) {
    return NextResponse.json({ error: "You are not currently on a break." }, { status: 400 });
  }

  const activeBreak = openBreaks[0];
  const breakDuration = Math.floor(
    (serverNow.getTime() - new Date(activeBreak.startTime).getTime()) / 1000
  );

  const [endedBreak] = await db
    .update(attendanceBreaks)
    .set({
      endTime: serverNow,
      durationSeconds: Math.max(0, breakDuration),
    })
    .where(eq(attendanceBreaks.id, activeBreak.id))
    .returning();

  // Recalculate total break seconds
  const allBreaks = await db
    .select()
    .from(attendanceBreaks)
    .where(eq(attendanceBreaks.attendanceId, activeAtt.id));

  let totalBreakSec = 0;
  for (const b of allBreaks) {
    if (b.endTime) totalBreakSec += b.durationSeconds;
  }

  await db
    .update(attendance)
    .set({ breakSeconds: totalBreakSec, updatedAt: serverNow })
    .where(eq(attendance.id, activeAtt.id));

  return NextResponse.json({ success: true, break: endedBreak });
}
