import { getSession } from "@/lib/auth";
import { db } from "@/db";
import { attendance, holidays, leaveRequests, schedules } from "@/db/schema";
import { getKarachiDateString } from "@/lib/time";
import { eq, and, gte, lte } from "drizzle-orm";
import { NextResponse } from "next/server";

export async function GET(req: Request) {
  const session = await getSession();
  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { searchParams } = new URL(req.url);
  const employeeId = searchParams.get("employeeId") || session.employeeId;
  const todayStr = getKarachiDateString();
  const [currentYear, currentMonthStr] = todayStr.split("-");

  const year = parseInt(searchParams.get("year") || currentYear, 10);
  const month = parseInt(searchParams.get("month") || currentMonthStr, 10);

  if (!employeeId) {
    return NextResponse.json({ error: "Employee ID required" }, { status: 400 });
  }

  // Permission check: regular employees can only view their own calendar
  if (session.role !== "ADMIN" && employeeId !== session.employeeId) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  const pad = (n: number) => String(n).padStart(2, "0");
  const monthStart = `${year}-${pad(month)}-01`;
  const lastDay = new Date(year, month, 0).getDate();
  const monthEnd = `${year}-${pad(month)}-${pad(lastDay)}`;

  // 1. Fetch Attendance Records
  const attRecords = await db
    .select()
    .from(attendance)
    .where(
      and(
        eq(attendance.employeeId, employeeId),
        gte(attendance.date, monthStart),
        lte(attendance.date, monthEnd)
      )
    );

  // 2. Fetch Holidays
  const holidayList = await db
    .select()
    .from(holidays)
    .where(and(gte(holidays.date, monthStart), lte(holidays.date, monthEnd)));

  // 3. Fetch Leaves
  const leaves = await db
    .select()
    .from(leaveRequests)
    .where(
      and(
        eq(leaveRequests.employeeId, employeeId),
        eq(leaveRequests.status, "APPROVED")
      )
    );

  // 4. Get Schedule
  const sched = await db.select().from(schedules).where(eq(schedules.isDefault, true));
  const workingDays: string[] = (sched[0]?.workingDays as string[]) || [
    "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"
  ];

  const attMap = new Map(attRecords.map((r) => [r.date, r]));
  const holidayMap = new Map(holidayList.map((h) => [h.date, h.name]));

  const calendarDays = [];

  for (let d = 1; d <= lastDay; d++) {
    const dateStr = `${year}-${pad(month)}-${pad(d)}`;
    const dateObj = new Date(`${dateStr}T00:00:00+05:00`);
    const dayName = new Intl.DateTimeFormat("en-US", { weekday: "long" }).format(dateObj);

    const isWorkingDay = workingDays.includes(dayName);
    const holidayName = holidayMap.get(dateStr);
    const approvedLeave = leaves.find((l) => l.startDate <= dateStr && l.endDate >= dateStr);
    const attRecord = attMap.get(dateStr);

    let status = "NONE";
    let badgeColor = "gray"; // default

    if (holidayName) {
      status = "HOLIDAY";
      badgeColor = "gray";
    } else if (approvedLeave) {
      status = "LEAVE";
      badgeColor = "purple";
    } else if (!isWorkingDay) {
      status = "WEEKEND";
      badgeColor = "slate";
    } else if (attRecord) {
      if (attRecord.attendanceStatus === "COMPLETED" || attRecord.attendanceStatus === "WORKING") {
        if (attRecord.arrivalStatus === "LATE") {
          status = "LATE";
          badgeColor = "amber";
        } else if (attRecord.arrivalStatus === "EARLY") {
          status = "EARLY";
          badgeColor = "blue";
        } else {
          status = "PRESENT";
          badgeColor = "emerald";
        }
      } else if (attRecord.attendanceStatus === "ABSENT") {
        status = "ABSENT";
        badgeColor = "rose";
      }
    } else if (dateStr < todayStr) {
      // Past working day without record -> ABSENT
      status = "ABSENT";
      badgeColor = "rose";
    }

    calendarDays.push({
      date: dateStr,
      dayNumber: d,
      dayName,
      isWorkingDay,
      status,
      badgeColor,
      holidayName: holidayName || null,
      leaveReason: approvedLeave?.reason || null,
      attendance: attRecord || null,
    });
  }

  return NextResponse.json({
    year,
    month,
    days: calendarDays,
  });
}
