import { getSession } from "@/lib/auth";
import { db } from "@/db";
import { attendance } from "@/db/schema";
import { eq, desc, and, gte, lte } from "drizzle-orm";
import { NextResponse } from "next/server";

export async function GET(req: Request) {
  const session = await getSession();
  if (!session || !session.employeeId) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { searchParams } = new URL(req.url);
  const startDate = searchParams.get("startDate");
  const endDate = searchParams.get("endDate");
  const statusFilter = searchParams.get("status");

  const conditions = [eq(attendance.employeeId, session.employeeId)];

  if (startDate) {
    conditions.push(gte(attendance.date, startDate));
  }
  if (endDate) {
    conditions.push(lte(attendance.date, endDate));
  }
  if (statusFilter && statusFilter !== "ALL") {
    conditions.push(eq(attendance.attendanceStatus, statusFilter as any));
  }

  const records = await db
    .select()
    .from(attendance)
    .where(and(...conditions))
    .orderBy(desc(attendance.date));

  return NextResponse.json({ records });
}
