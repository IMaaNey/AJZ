import { getSession } from "@/lib/auth";
import { db } from "@/db";
import { attendance, attendanceBreaks } from "@/db/schema";
import { getKarachiDateString, getKarachiNow } from "@/lib/time";
import { eq, and, isNull } from "drizzle-orm";
import { NextResponse } from "next/server";

export async function POST(req: Request) {
  const session = await getSession();
  if (!session || !session.employeeId) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { breakType = "LUNCH", notes = "" } = (await req.json().catch(() => ({})));
  const dateStr = getKarachiDateString();
  const serverNow = getKarachiNow();

  // Find active attendance
  const attList = await db
    .select()
    .from(attendance)
    .where(
      and(
        eq(attendance.employeeId, session.employeeId),
        eq(attendance.date, dateStr),
        eq(attendance.attendanceStatus, "WORKING")
      )
    );

  if (attList.length === 0) {
    return NextResponse.json(
      { error: "You must be clocked in and working to start a break." },
      { status: 400 }
    );
  }

  const activeAtt = attList[0];

  // Check if already on break
  const openBreaks = await db
    .select()
    .from(attendanceBreaks)
    .where(
      and(
        eq(attendanceBreaks.attendanceId, activeAtt.id),
        isNull(attendanceBreaks.endTime)
      )
    );

  if (openBreaks.length > 0) {
    return NextResponse.json(
      { error: "You are already on a break." },
      { status: 400 }
    );
  }

  const [newBreak] = await db
    .insert(attendanceBreaks)
    .values({
      attendanceId: activeAtt.id,
      startTime: serverNow,
      breakType,
      notes,
    })
    .returning();

  return NextResponse.json({ success: true, break: newBreak });
}
