import { getSession } from "@/lib/auth";
import { db } from "@/db";
import { attendance, attendanceBreaks } from "@/db/schema";
import { getKarachiDateString, getKarachiNow } from "@/lib/time";
import { eq, and, isNull } from "drizzle-orm";
import { NextResponse } from "next/server";

export async function POST() {
  const session = await getSession();
  if (!session || !session.employeeId) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const dateStr = getKarachiDateString();
  const serverNow = getKarachiNow();

  // Find active attendance session for today
  const attList = await db
    .select()
    .from(attendance)
    .where(
      and(
        eq(attendance.employeeId, session.employeeId),
        eq(attendance.date, dateStr),
        eq(attendance.attendanceStatus, "WORKING")
      )
    );

  if (attList.length === 0) {
    return NextResponse.json(
      { error: "No active working session found to clock out." },
      { status: 400 }
    );
  }

  const activeAtt = attList[0];

  // 1. Auto-close active break if any
  const openBreaks = await db
    .select()
    .from(attendanceBreaks)
    .where(
      and(
        eq(attendanceBreaks.attendanceId, activeAtt.id),
        isNull(attendanceBreaks.endTime)
      )
    );

  for (const b of openBreaks) {
    const breakDuration = Math.floor(
      (serverNow.getTime() - new Date(b.startTime).getTime()) / 1000
    );
    await db
      .update(attendanceBreaks)
      .set({
        endTime: serverNow,
        durationSeconds: Math.max(0, breakDuration),
      })
      .where(eq(attendanceBreaks.id, b.id));
  }

  // 2. Calculate total break seconds
  const allBreaks = await db
    .select()
    .from(attendanceBreaks)
    .where(eq(attendanceBreaks.attendanceId, activeAtt.id));

  let totalBreakSec = 0;
  for (const b of allBreaks) {
    if (b.endTime) {
      totalBreakSec += b.durationSeconds;
    } else {
      // should have been updated above, but safety check:
      const d = Math.floor((serverNow.getTime() - new Date(b.startTime).getTime()) / 1000);
      totalBreakSec += Math.max(0, d);
    }
  }

  // 3. Calculate working duration
  const clockInMs = new Date(activeAtt.clockIn).getTime();
  const totalWorkSec = Math.floor((serverNow.getTime() - clockInMs) / 1000);
  const actualWorkSec = Math.max(0, totalWorkSec - totalBreakSec);

  const [updatedAtt] = await db
    .update(attendance)
    .set({
      clockOut: serverNow,
      totalWorkSeconds: totalWorkSec,
      breakSeconds: totalBreakSec,
      actualWorkSeconds: actualWorkSec,
      attendanceStatus: "COMPLETED",
      updatedAt: serverNow,
    })
    .where(eq(attendance.id, activeAtt.id))
    .returning();

  return NextResponse.json({
    success: true,
    attendance: updatedAtt,
  });
}
