import { getSession } from "@/lib/auth";
import { db } from "@/db";
import { employees, users, schedules } from "@/db/schema";
import { eq } from "drizzle-orm";
import { NextResponse } from "next/server";

export async function GET() {
  const session = await getSession();
  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const u = await db.select().from(users).where(eq(users.id, session.userId));
  if (u.length === 0) {
    return NextResponse.json({ error: "User not found" }, { status: 404 });
  }

  let emp = null;
  let schedule = null;

  if (session.employeeId) {
    const e = await db.select().from(employees).where(eq(employees.id, session.employeeId));
    if (e.length > 0) emp = e[0];
  }

  const schedList = await db.select().from(schedules).where(eq(schedules.isDefault, true));
  schedule = schedList[0] || null;

  return NextResponse.json({
    user: {
      id: u[0].id,
      email: u[0].email,
      role: u[0].role,
      status: u[0].status,
    },
    employee: emp,
    schedule,
  });
}

export async function PUT(req: Request) {
  const session = await getSession();
  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { phone, fullName } = await req.json();

  if (session.employeeId) {
    await db
      .update(employees)
      .set({
        phone: phone ?? undefined,
        fullName: fullName ?? undefined,
        updatedAt: new Date(),
      })
      .where(eq(employees.id, session.employeeId));
  }

  return NextResponse.json({ success: true, message: "Profile updated successfully" });
}
