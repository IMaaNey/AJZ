import { getSession } from "@/lib/auth";
import { db } from "@/db";
import { employees, users, schedules } from "@/db/schema";
import { eq } from "drizzle-orm";
import { NextResponse } from "next/server";

export async function GET() {
  const session = await getSession();

  if (!session) {
    return NextResponse.json({ authenticated: false }, { status: 401 });
  }

  // Fetch full user and employee detail
  const userList = await db.select().from(users).where(eq(users.id, session.userId));
  if (userList.length === 0 || userList[0].status !== "ACTIVE") {
    return NextResponse.json({ authenticated: false }, { status: 401 });
  }

  const user = userList[0];
  let empProfile = null;
  let scheduleDetails = null;

  if (session.employeeId) {
    const empList = await db.select().from(employees).where(eq(employees.id, session.employeeId));
    if (empList.length > 0) {
      empProfile = empList[0];
      if (empProfile.scheduleId) {
        const schedList = await db.select().from(schedules).where(eq(schedules.id, empProfile.scheduleId));
        if (schedList.length > 0) scheduleDetails = schedList[0];
      }
    }
  }

  // If no custom schedule, fetch default
  if (!scheduleDetails) {
    const defaultSched = await db.select().from(schedules).where(eq(schedules.isDefault, true));
    if (defaultSched.length > 0) scheduleDetails = defaultSched[0];
  }

  return NextResponse.json({
    authenticated: true,
    user: {
      id: user.id,
      email: user.email,
      role: user.role,
      fullName: empProfile ? empProfile.fullName : (user.role === "ADMIN" ? "Admin Manager" : "Employee"),
      employeeId: session.employeeId,
      department: empProfile?.departmentName || "General",
      designation: empProfile?.designation || "Staff",
      employeeCode: empProfile?.employeeCode || "AJZ-000",
      joiningDate: empProfile?.joiningDate || "",
    },
    schedule: scheduleDetails,
  });
}
