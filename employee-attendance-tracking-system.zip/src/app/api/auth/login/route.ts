import { db } from "@/db";
import { users, employees } from "@/db/schema";
import { verifyPassword, setSessionCookie } from "@/lib/auth";
import { eq } from "drizzle-orm";
import { NextResponse } from "next/server";

export async function POST(req: Request) {
  try {
    const { email, password } = await req.json();

    if (!email || !password) {
      return NextResponse.json(
        { error: "Email and password are required" },
        { status: 400 }
      );
    }

    const cleanEmail = String(email).trim().toLowerCase();

    // Find user
    const userList = await db
      .select()
      .from(users)
      .where(eq(users.email, cleanEmail));

    if (userList.length === 0) {
      return NextResponse.json(
        { error: "Invalid official email or password" },
        { status: 401 }
      );
    }

    const user = userList[0];

    if (user.status !== "ACTIVE") {
      return NextResponse.json(
        { error: "Your account is deactivated. Please contact HR Administration." },
        { status: 403 }
      );
    }

    const isMatch = await verifyPassword(password, user.passwordHash);
    if (!isMatch) {
      return NextResponse.json(
        { error: "Invalid official email or password" },
        { status: 401 }
      );
    }

    // Get employee record if exists
    let employeeId: string | undefined = undefined;
    let fullName = "User";

    const empList = await db
      .select()
      .from(employees)
      .where(eq(employees.userId, user.id));

    if (empList.length > 0) {
      employeeId = empList[0].id;
      fullName = empList[0].fullName;
    } else {
      fullName = user.role === "ADMIN" ? "Admin Director" : "Employee";
    }

    await setSessionCookie({
      userId: user.id,
      email: user.email,
      role: user.role,
      employeeId,
      fullName,
    });

    const redirectUrl = user.role === "ADMIN" ? "/admin/dashboard" : "/employee/dashboard";

    return NextResponse.json({
      success: true,
      user: {
        id: user.id,
        email: user.email,
        role: user.role,
        fullName,
        employeeId,
      },
      redirectUrl,
    });
  } catch (err: unknown) {
    console.error("Login error:", err);
    return NextResponse.json(
      { error: "An error occurred during authentication" },
      { status: 500 }
    );
  }
}
