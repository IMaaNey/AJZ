export const TIMEZONE = "Asia/Karachi";

/**
 * Returns current Date in Asia/Karachi timezone ISO string or Date object.
 */
export function getKarachiNow(): Date {
  return new Date();
}

/**
 * Returns YYYY-MM-DD date string in Asia/Karachi time.
 */
export function getKarachiDateString(date: Date = new Date()): string {
  const formatter = new Intl.DateTimeFormat("en-CA", {
    timeZone: TIMEZONE,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  });
  return formatter.format(date); // Output format: YYYY-MM-DD
}

/**
 * Returns formatted time string in 12-hour format with AM/PM for Asia/Karachi, e.g. "08:52 AM".
 */
export function formatKarachiTime(date: Date | string | null): string {
  if (!date) return "—";
  const d = typeof date === "string" ? new Date(date) : date;
  if (isNaN(d.getTime())) return "—";

  return new Intl.DateTimeFormat("en-US", {
    timeZone: TIMEZONE,
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: true,
  }).format(d);
}

/**
 * Format timestamp to e.g. "08:52:10 AM" or "08:52 AM" (without seconds if short=true).
 */
export function formatKarachiTimeShort(date: Date | string | null): string {
  if (!date) return "—";
  const d = typeof date === "string" ? new Date(date) : date;
  if (isNaN(d.getTime())) return "—";

  return new Intl.DateTimeFormat("en-US", {
    timeZone: TIMEZONE,
    hour: "2-digit",
    minute: "2-digit",
    hour12: true,
  }).format(d);
}

/**
 * Parse HH:mm (e.g., "09:00") and a date string (YYYY-MM-DD) into a JS Date object in Asia/Karachi time.
 */
export function parseScheduleTimeToDate(dateStr: string, timeStr: string): Date {
  const [hours, minutes] = timeStr.split(":").map(Number);
  // Create ISO string for Asia/Karachi (+05:00)
  const pad = (n: number) => String(n).padStart(2, "0");
  const isoStr = `${dateStr}T${pad(hours)}:${pad(minutes)}:00+05:00`;
  return new Date(isoStr);
}

/**
 * Format total seconds to readable format e.g. "08h 06m" or "00h 00m 00s".
 */
export function formatDuration(seconds: number, includeSeconds = false): string {
  if (seconds < 0) seconds = 0;
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);

  const pad = (n: number) => String(n).padStart(2, "0");

  if (includeSeconds) {
    return `${pad(h)}h ${pad(m)}m ${pad(s)}s`;
  }
  return `${pad(h)}h ${pad(m)}m`;
}

/**
 * Format 24h schedule time (e.g., "09:00") to 12h format (e.g., "09:00 AM").
 */
export function format12Hour(time24: string): string {
  if (!time24) return "—";
  const [hStr, mStr] = time24.split(":");
  let h = parseInt(hStr, 10);
  if (isNaN(h)) return time24;
  const ampm = h >= 12 ? "PM" : "AM";
  h = h % 12;
  if (h === 0) h = 12;
  return `${String(h).padStart(2, "0")}:${mStr} ${ampm}`;
}

/**
 * Calculate arrival status: EARLY, ON_TIME, or LATE based on clockIn time, scheduled start time, and grace period minutes.
 */
export function calculateArrivalStatus(
  clockInDate: Date,
  dateStr: string,
  startTime24: string,
  gracePeriodMinutes: number
): {
  arrivalStatus: "EARLY" | "ON_TIME" | "LATE";
  arrivalMinutes: number;
  label: string;
} {
  const scheduledDate = parseScheduleTimeToDate(dateStr, startTime24);
  const diffMs = clockInDate.getTime() - scheduledDate.getTime();
  const diffMinutes = Math.round(diffMs / (1000 * 60));

  if (diffMinutes <= 0) {
    const earlyMins = Math.abs(diffMinutes);
    return {
      arrivalStatus: "EARLY",
      arrivalMinutes: diffMinutes,
      label: earlyMins === 0 ? "On Time" : `Early by ${earlyMins} ${earlyMins === 1 ? "minute" : "minutes"}`,
    };
  } else if (diffMinutes <= gracePeriodMinutes) {
    return {
      arrivalStatus: "ON_TIME",
      arrivalMinutes: diffMinutes,
      label: `On Time (${diffMinutes}m grace)`,
    };
  } else {
    return {
      arrivalStatus: "LATE",
      arrivalMinutes: diffMinutes,
      label: `Late by ${diffMinutes} ${diffMinutes === 1 ? "minute" : "minutes"}`,
    };
  }
}
