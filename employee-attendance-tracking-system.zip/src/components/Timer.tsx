"use client";

import { useEffect, useState } from "react";

interface TimerProps {
  clockInIso: string;
  totalBreakSeconds: number;
  activeBreakStartIso?: string | null;
  isWorking: boolean;
}

export function Timer({
  clockInIso,
  totalBreakSeconds,
  activeBreakStartIso,
  isWorking,
}: TimerProps) {
  const [seconds, setSeconds] = useState<number>(0);

  useEffect(() => {
    if (!isWorking || !clockInIso) return;

    const calculateElapsed = () => {
      const nowMs = new Date().getTime();
      const clockInMs = new Date(clockInIso).getTime();
      const totalElapsedSec = Math.floor((nowMs - clockInMs) / 1000);

      let activeBreakSec = 0;
      if (activeBreakStartIso) {
        const breakStartMs = new Date(activeBreakStartIso).getTime();
        activeBreakSec = Math.floor((nowMs - breakStartMs) / 1000);
      }

      const totalBreakSec = totalBreakSeconds + activeBreakSec;
      const actualWorkingSec = Math.max(0, totalElapsedSec - totalBreakSec);
      setSeconds(actualWorkingSec);
    };

    calculateElapsed();
    const interval = setInterval(calculateElapsed, 1000);
    return () => clearInterval(interval);
  }, [clockInIso, totalBreakSeconds, activeBreakStartIso, isWorking]);

  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);

  const pad = (n: number) => String(n).padStart(2, "0");

  return (
    <div className="font-mono text-3xl md:text-5xl font-extrabold tracking-tight text-amber-600 dark:text-amber-400">
      <span>{pad(h)}</span>
      <span className="text-slate-400 text-2xl md:text-4xl">h </span>
      <span>{pad(m)}</span>
      <span className="text-slate-400 text-2xl md:text-4xl">m </span>
      <span>{pad(s)}</span>
      <span className="text-slate-400 text-2xl md:text-4xl">s</span>
    </div>
  );
}
