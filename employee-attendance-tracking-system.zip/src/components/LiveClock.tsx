"use client";

import { useEffect, useState } from "react";

export function LiveClock() {
  const [timeString, setTimeString] = useState<string>("");
  const [dateString, setDateString] = useState<string>("");

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      
      const timeFmt = new Intl.DateTimeFormat("en-US", {
        timeZone: "Asia/Karachi",
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit",
        hour12: true,
      });

      const dateFmt = new Intl.DateTimeFormat("en-US", {
        timeZone: "Asia/Karachi",
        weekday: "long",
        year: "numeric",
        month: "long",
        day: "numeric",
      });

      setTimeString(timeFmt.format(now));
      setDateString(dateFmt.format(now));
    };

    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  if (!timeString) {
    return (
      <div className="text-right">
        <div className="h-5 w-48 bg-slate-200 dark:bg-slate-700 animate-pulse rounded"></div>
        <div className="h-4 w-32 bg-slate-200 dark:bg-slate-700 animate-pulse rounded mt-1"></div>
      </div>
    );
  }

  return (
    <div className="text-right">
      <div className="text-sm font-semibold text-slate-800 dark:text-slate-100 flex items-center justify-end gap-1.5">
        <span className="inline-block w-2 h-2 rounded-full bg-emerald-500 animate-ping"></span>
        <span>{timeString}</span>
        <span className="text-xs px-1.5 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-500 font-mono">
          PKT
        </span>
      </div>
      <div className="text-xs text-slate-500 dark:text-slate-400 font-medium">
        {dateString}
      </div>
    </div>
  );
}
