"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  LayoutDashboard,
  Users,
  Clock,
  Calendar,
  BarChart3,
  CalendarOff,
  FileCheck2,
  Settings,
  ShieldAlert,
  User,
  LogOut,
  Building2,
  X,
} from "lucide-react";

interface SidebarProps {
  role: "ADMIN" | "EMPLOYEE";
  userName: string;
  userEmail: string;
  isOpenMobile?: boolean;
  onCloseMobile?: () => void;
  onLogout: () => void;
}

export function Sidebar({
  role,
  userName,
  userEmail,
  isOpenMobile,
  onCloseMobile,
  onLogout,
}: SidebarProps) {
  const pathname = usePathname();

  const employeeLinks = [
    { name: "Dashboard", href: "/employee/dashboard", icon: LayoutDashboard },
    { name: "My Attendance", href: "/employee/attendance", icon: Clock },
    { name: "My Calendar", href: "/employee/calendar", icon: Calendar },
    { name: "My Reports", href: "/employee/reports", icon: BarChart3 },
    { name: "Profile", href: "/employee/profile", icon: User },
  ];

  const adminLinks = [
    { name: "Dashboard", href: "/admin/dashboard", icon: LayoutDashboard },
    { name: "Employees", href: "/admin/employees", icon: Users },
    { name: "Attendance", href: "/admin/attendance", icon: Clock },
    { name: "Reports", href: "/admin/reports", icon: BarChart3 },
    { name: "Calendar", href: "/admin/calendar", icon: Calendar },
    { name: "Holidays", href: "/admin/holidays", icon: CalendarOff },
    { name: "Leave Management", href: "/admin/leave", icon: FileCheck2 },
    { name: "Settings", href: "/admin/settings", icon: Settings },
    { name: "Audit Logs", href: "/admin/audit-logs", icon: ShieldAlert },
  ];

  const navLinks = role === "ADMIN" ? adminLinks : employeeLinks;

  return (
    <>
      {/* Mobile overlay */}
      {isOpenMobile && (
        <div
          className="fixed inset-0 z-40 bg-slate-900/60 backdrop-blur-xs lg:hidden"
          onClick={onCloseMobile}
        />
      )}

      <aside
        className={`fixed top-0 bottom-0 left-0 z-50 w-64 bg-slate-900 text-slate-100 flex flex-col transition-transform duration-300 ease-in-out lg:translate-x-0 ${
          isOpenMobile ? "translate-x-0" : "-translate-x-full"
        }`}
      >
        {/* Header Branding */}
        <div className="p-5 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-600 flex items-center justify-center text-white font-bold shadow-lg shadow-amber-500/30">
              AJZ
            </div>
            <div>
              <h1 className="font-extrabold text-base tracking-tight text-white">
                AJZ Consultants
              </h1>
              <p className="text-xs text-amber-400 font-medium">HRMS Portal</p>
            </div>
          </div>
          {onCloseMobile && (
            <button
              onClick={onCloseMobile}
              className="lg:hidden p-1 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800"
            >
              <X className="w-5 h-5" />
            </button>
          )}
        </div>

        {/* User Role Tag */}
        <div className="px-5 py-3 bg-slate-850 border-b border-slate-800 flex items-center justify-between text-xs">
          <span className="text-slate-400 font-medium">Logged in as:</span>
          <span
            className={`px-2 py-0.5 rounded-full text-[10px] font-bold tracking-wide uppercase ${
              role === "ADMIN"
                ? "bg-amber-500/20 text-amber-400 border border-amber-500/30"
                : "bg-emerald-500/20 text-emerald-400 border border-emerald-500/30"
            }`}
          >
            {role}
          </span>
        </div>

        {/* Navigation List */}
        <nav className="flex-1 overflow-y-auto px-3 py-4 space-y-1">
          {navLinks.map((link) => {
            const Icon = link.icon;
            const isActive =
              pathname === link.href ||
              (link.href !== "/admin/dashboard" &&
                link.href !== "/employee/dashboard" &&
                pathname.startsWith(link.href));

            return (
              <Link
                key={link.href}
                href={link.href}
                onClick={onCloseMobile}
                className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all ${
                  isActive
                    ? "bg-amber-600 text-white font-semibold shadow-md shadow-amber-500/20"
                    : "text-slate-300 hover:bg-slate-800 hover:text-white"
                }`}
              >
                <Icon className={`w-5 h-5 ${isActive ? "text-white" : "text-slate-400"}`} />
                <span>{link.name}</span>
              </Link>
            );
          })}
        </nav>

        {/* Profile Footer & Logout */}
        <div className="p-4 border-t border-slate-800 bg-slate-950/50">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-9 h-9 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center font-bold text-slate-200">
              {userName.charAt(0).toUpperCase()}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-semibold text-white truncate">{userName}</p>
              <p className="text-xs text-slate-400 truncate">{userEmail}</p>
            </div>
          </div>

          <button
            onClick={onLogout}
            className="w-full flex items-center justify-center gap-2 px-3 py-2 rounded-lg bg-rose-500/10 text-rose-400 hover:bg-rose-500/20 border border-rose-500/20 text-xs font-semibold transition-all"
          >
            <LogOut className="w-4 h-4" />
            <span>Sign Out</span>
          </button>
        </div>
      </aside>
    </>
  );
}
