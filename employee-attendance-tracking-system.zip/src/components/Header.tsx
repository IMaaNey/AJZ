"use client";

import { Menu } from "lucide-react";
import { LiveClock } from "./LiveClock";

interface HeaderProps {
  userName: string;
  role: string;
  department?: string;
  onOpenMobileNav: () => void;
}

export function Header({
  userName,
  role,
  department = "AJZ Consultants",
  onOpenMobileNav,
}: HeaderProps) {
  return (
    <header className="sticky top-0 z-30 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 px-4 lg:px-8 py-3 flex items-center justify-between shadow-xs">
      <div className="flex items-center gap-3">
        <button
          onClick={onOpenMobileNav}
          className="lg:hidden p-2 rounded-lg text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800"
          aria-label="Open navigation"
        >
          <Menu className="w-6 h-6" />
        </button>

        <div>
          <h2 className="text-base font-bold text-slate-800 dark:text-white tracking-tight">
            AJZ Consultants Portal
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 font-medium hidden sm:block">
            {department} • HRMS Time Tracking
          </p>
        </div>
      </div>

      <div className="flex items-center gap-4">
        <LiveClock />
      </div>
    </header>
  );
}
