import { db } from "./index";
import {
  users,
  employees,
  departments,
  schedules,
  holidays,
  attendance,
  auditLogs,
} from "./schema";
import { hashPassword } from "../lib/auth";
import { eq } from "drizzle-orm";

export async function seedDatabase() {
  console.log("Checking if seed is required...");

  // Check if admin user already exists
  const existingAdmin = await db.query ? undefined : null; // we will use select
  const existingUsers = await db.select().from(users).where(eq(users.email, "admin@ajzconsultants.com"));
  
  if (existingUsers.length > 0) {
    console.log("Database already seeded!");
    return;
  }

  console.log("Seeding database...");

  // 1. Create Default Schedule
  const [schedule] = await db
    .insert(schedules)
    .values({
      companyName: "AJZ Consultants",
      timezone: "Asia/Karachi",
      startTime: "09:00",
      endTime: "18:00",
      gracePeriodMinutes: 15,
      lunchBreakStart: "13:00",
      lunchBreakEnd: "14:00",
      workingDays: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"],
      breakTrackingEnabled: true,
      isDefault: true,
    })
    .returning();

  // 2. Create Departments
  const deptNames = ["Engineering", "Human Resources", "Sales & Marketing", "Operations", "Finance"];
  const createdDepts: Record<string, string> = {};

  for (const name of deptNames) {
    const [dept] = await db
      .insert(departments)
      .values({
        name,
        description: `${name} Department at AJZ Consultants`,
      })
      .returning();
    createdDepts[name] = dept.id;
  }

  // Common password hash
  const defaultPasswordHash = await hashPassword("DemoPassword123");

  // 3. Create Admin User & Employee
  const [adminUser] = await db
    .insert(users)
    .values({
      email: "admin@ajzconsultants.com",
      passwordHash: defaultPasswordHash,
      role: "ADMIN",
      status: "ACTIVE",
    })
    .returning();

  const [adminEmp] = await db
    .insert(employees)
    .values({
      userId: adminUser.id,
      employeeCode: "AJZ-001",
      fullName: "Admin Director",
      officialEmail: "admin@ajzconsultants.com",
      departmentId: createdDepts["Operations"],
      departmentName: "Operations",
      designation: "HR Director & Administrator",
      joiningDate: "2024-01-01",
      phone: "+92 300 1234567",
      scheduleId: schedule.id,
      status: "ACTIVE",
    })
    .returning();

  // 4. Create Demo Employees
  const demoEmployeesList = [
    {
      email: "employee1@ajzconsultants.com",
      name: "Ahmed Khan",
      code: "AJZ-101",
      dept: "Engineering",
      designation: "Senior Full Stack Engineer",
      joiningDate: "2024-03-15",
    },
    {
      email: "employee2@ajzconsultants.com",
      name: "Sara Ali",
      code: "AJZ-102",
      dept: "Human Resources",
      designation: "HR Manager",
      joiningDate: "2024-05-01",
    },
    {
      email: "employee3@ajzconsultants.com",
      name: "Bilal Ahmed",
      code: "AJZ-103",
      dept: "Sales & Marketing",
      designation: "Sales Executive Lead",
      joiningDate: "2024-06-10",
    },
    {
      email: "test@ajzconsultants.com",
      name: "Test Employee",
      code: "AJZ-104",
      dept: "Operations",
      designation: "Operations Specialist",
      joiningDate: "2024-07-01",
    },
  ];

  const createdEmpRecords: { id: string; name: string }[] = [];

  for (const item of demoEmployeesList) {
    const [u] = await db
      .insert(users)
      .values({
        email: item.email,
        passwordHash: defaultPasswordHash,
        role: "EMPLOYEE",
        status: "ACTIVE",
      })
      .returning();

    const [emp] = await db
      .insert(employees)
      .values({
        userId: u.id,
        employeeCode: item.code,
        fullName: item.name,
        officialEmail: item.email,
        departmentId: createdDepts[item.dept],
        departmentName: item.dept,
        designation: item.designation,
        joiningDate: item.joiningDate,
        phone: "+92 321 9876543",
        scheduleId: schedule.id,
        status: "ACTIVE",
      })
      .returning();

    createdEmpRecords.push({ id: emp.id, name: emp.fullName });
  }

  // 5. Create Sample Holidays
  const holidaysData = [
    { name: "New Year's Day", date: "2026-01-01", description: "Official Company Holiday" },
    { name: "Kashmir Day", date: "2026-02-05", description: "Public Holiday" },
    { name: "Pakistan Day", date: "2026-03-23", description: "National Holiday" },
    { name: "Labor Day", date: "2026-05-01", description: "International Workers' Day" },
    { name: "Independence Day", date: "2026-08-14", description: "Pakistan Independence Day" },
  ];

  for (const h of holidaysData) {
    await db.insert(holidays).values(h);
  }

  // 6. Generate Historical Attendance Records for testing statistics
  const today = new Date();
  for (let i = 1; i <= 10; i++) {
    const pastDate = new Date(today);
    pastDate.setDate(today.getDate() - i);

    // Skip Sunday if Sunday is non-working
    if (pastDate.getDay() === 0) continue;

    const pad = (n: number) => String(n).padStart(2, "0");
    const dateStr = `${pastDate.getFullYear()}-${pad(pastDate.getMonth() + 1)}-${pad(pastDate.getDate())}`;

    // Skip Independence day
    if (dateStr === "2026-08-14") continue;

    for (const empRec of createdEmpRecords) {
      // Simulate random variation in arrival
      const isLate = Math.random() < 0.25;
      const isEarly = !isLate && Math.random() < 0.5;

      let clockInHour = 8;
      let clockInMin = 50 + Math.floor(Math.random() * 9); // 08:50 - 08:58 (Early)
      let arrivalStatus: "EARLY" | "ON_TIME" | "LATE" = "EARLY";
      let arrivalMinutes = -8;

      if (isLate) {
        clockInHour = 9;
        clockInMin = 18 + Math.floor(Math.random() * 20); // 09:18 - 09:38 (Late)
        arrivalStatus = "LATE";
        arrivalMinutes = clockInMin;
      } else if (!isEarly) {
        clockInHour = 9;
        clockInMin = Math.floor(Math.random() * 10); // 09:00 - 09:09 (On Time)
        arrivalStatus = "ON_TIME";
        arrivalMinutes = clockInMin;
      }

      const clockInTime = new Date(`${dateStr}T${pad(clockInHour)}:${pad(clockInMin)}:00+05:00`);
      const clockOutTime = new Date(`${dateStr}T17:58:00+05:00`);

      const totalWorkSec = Math.floor((clockOutTime.getTime() - clockInTime.getTime()) / 1000);
      const breakSec = 3600; // 1 hour break
      const actualWorkSec = totalWorkSec - breakSec;

      await db.insert(attendance).values({
        employeeId: empRec.id,
        date: dateStr,
        scheduledStart: "09:00 AM",
        scheduledEnd: "06:00 PM",
        clockIn: clockInTime,
        clockOut: clockOutTime,
        totalWorkSeconds: totalWorkSec,
        breakSeconds: breakSec,
        actualWorkSeconds: actualWorkSec,
        arrivalStatus,
        arrivalMinutes,
        attendanceStatus: "COMPLETED",
        notes: "Regular Workday",
      });
    }
  }

  // 7. Seed Initial Audit Logs
  await db.insert(auditLogs).values({
    adminId: adminUser.id,
    adminName: "Admin Director",
    action: "SYSTEM_INITIALIZED",
    target: "AJZ Consultants Portal",
    details: "Initialized system settings, schedules, default departments and demo users.",
  });

  console.log("Database seed completed successfully!");
}
