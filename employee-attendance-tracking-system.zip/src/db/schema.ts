import {
  pgTable,
  text,
  timestamp,
  integer,
  boolean,
  uuid,
  date,
  jsonb,
} from "drizzle-orm/pg-core";

// Departments Table
export const departments = pgTable("departments", {
  id: uuid("id").defaultRandom().primaryKey(),
  name: text("name").notNull().unique(),
  description: text("description"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Schedules Table (Working Schedule & Grace Period settings)
export const schedules = pgTable("schedules", {
  id: uuid("id").defaultRandom().primaryKey(),
  companyName: text("company_name").default("AJZ Consultants").notNull(),
  timezone: text("timezone").default("Asia/Karachi").notNull(),
  startTime: text("start_time").default("09:00").notNull(), // HH:mm format
  endTime: text("end_time").default("18:00").notNull(), // HH:mm format
  gracePeriodMinutes: integer("grace_period_minutes").default(15).notNull(),
  lunchBreakStart: text("lunch_break_start").default("13:00").notNull(),
  lunchBreakEnd: text("lunch_break_end").default("14:00").notNull(),
  workingDays: jsonb("working_days")
    .$type<string[]>()
    .default(["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"])
    .notNull(),
  breakTrackingEnabled: boolean("break_tracking_enabled").default(true).notNull(),
  isDefault: boolean("is_default").default(true).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Users Table (Auth credentials & role)
export const users = pgTable("users", {
  id: uuid("id").defaultRandom().primaryKey(),
  email: text("email").notNull().unique(),
  passwordHash: text("password_hash").notNull(),
  role: text("role").$type<"ADMIN" | "EMPLOYEE">().default("EMPLOYEE").notNull(),
  status: text("status").$type<"ACTIVE" | "INACTIVE">().default("ACTIVE").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Employees Table (Detailed profile)
export const employees = pgTable("employees", {
  id: uuid("id").defaultRandom().primaryKey(),
  userId: uuid("user_id")
    .references(() => users.id, { onDelete: "cascade" })
    .notNull(),
  employeeCode: text("employee_code").notNull().unique(),
  fullName: text("full_name").notNull(),
  officialEmail: text("official_email").notNull().unique(),
  departmentId: uuid("department_id").references(() => departments.id, {
    onDelete: "set null",
  }),
  departmentName: text("department_name").default("General").notNull(),
  designation: text("designation").default("Software Engineer").notNull(),
  joiningDate: date("joining_date").notNull(),
  phone: text("phone"),
  scheduleId: uuid("schedule_id").references(() => schedules.id, {
    onDelete: "set null",
  }),
  status: text("status").$type<"ACTIVE" | "INACTIVE">().default("ACTIVE").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Attendance Table
export const attendance = pgTable("attendance", {
  id: uuid("id").defaultRandom().primaryKey(),
  employeeId: uuid("employee_id")
    .references(() => employees.id, { onDelete: "cascade" })
    .notNull(),
  date: text("date").notNull(), // YYYY-MM-DD format (Asia/Karachi date)
  scheduledStart: text("scheduled_start").notNull(), // e.g. "09:00 AM"
  scheduledEnd: text("scheduled_end").notNull(), // e.g. "06:00 PM"
  clockIn: timestamp("clock_in", { withTimezone: true }).notNull(),
  clockOut: timestamp("clock_out", { withTimezone: true }),
  totalWorkSeconds: integer("total_work_seconds").default(0).notNull(),
  breakSeconds: integer("break_seconds").default(0).notNull(),
  actualWorkSeconds: integer("actual_work_seconds").default(0).notNull(),
  arrivalStatus: text("arrival_status")
    .$type<"EARLY" | "ON_TIME" | "LATE">()
    .default("ON_TIME")
    .notNull(),
  arrivalMinutes: integer("arrival_minutes").default(0).notNull(), // negative for early, positive for late
  attendanceStatus: text("attendance_status")
    .$type<"WORKING" | "COMPLETED" | "ABSENT" | "LEAVE" | "HOLIDAY" | "HALF_DAY">()
    .default("WORKING")
    .notNull(),
  notes: text("notes"),
  isManualEntry: boolean("is_manual_entry").default(false).notNull(),
  editedBy: uuid("edited_by").references(() => users.id, { onDelete: "set null" }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Attendance Breaks Table
export const attendanceBreaks = pgTable("attendance_breaks", {
  id: uuid("id").defaultRandom().primaryKey(),
  attendanceId: uuid("attendance_id")
    .references(() => attendance.id, { onDelete: "cascade" })
    .notNull(),
  startTime: timestamp("start_time", { withTimezone: true }).notNull(),
  endTime: timestamp("end_time", { withTimezone: true }),
  durationSeconds: integer("duration_seconds").default(0).notNull(),
  breakType: text("break_type").default("LUNCH").notNull(),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Holidays Table
export const holidays = pgTable("holidays", {
  id: uuid("id").defaultRandom().primaryKey(),
  name: text("name").notNull(),
  date: text("date").notNull(), // YYYY-MM-DD
  description: text("description"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Leave Requests Table
export const leaveRequests = pgTable("leave_requests", {
  id: uuid("id").defaultRandom().primaryKey(),
  employeeId: uuid("employee_id")
    .references(() => employees.id, { onDelete: "cascade" })
    .notNull(),
  leaveType: text("leave_type")
    .$type<"ANNUAL" | "SICK" | "CASUAL">()
    .default("CASUAL")
    .notNull(),
  startDate: text("start_date").notNull(), // YYYY-MM-DD
  endDate: text("end_date").notNull(), // YYYY-MM-DD
  reason: text("reason").notNull(),
  status: text("status")
    .$type<"PENDING" | "APPROVED" | "REJECTED">()
    .default("PENDING")
    .notNull(),
  reviewedBy: uuid("reviewed_by").references(() => users.id, { onDelete: "set null" }),
  reviewReason: text("review_reason"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Audit Logs Table
export const auditLogs = pgTable("audit_logs", {
  id: uuid("id").defaultRandom().primaryKey(),
  adminId: uuid("admin_id").references(() => users.id, { onDelete: "set null" }),
  adminName: text("admin_name").notNull(),
  action: text("action").notNull(), // e.g. "EMPLOYEE_CREATED", "ATTENDANCE_EDITED"
  target: text("target").notNull(), // e.g. "Ahmed Khan (ahmed@ajzconsultants.com)"
  details: text("details"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Company Settings Table
export const companySettings = pgTable("company_settings", {
  id: uuid("id").defaultRandom().primaryKey(),
  key: text("key").notNull().unique(),
  value: text("value").notNull(),
  description: text("description"),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});
